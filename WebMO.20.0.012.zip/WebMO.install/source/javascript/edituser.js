function ChangePassword(form)
{
	form.operation.value="ChangePassword";
	form.submit();
}
    		
function ChangeProfile(form)
{
	form.operation.value="ChangeProfile";
	form.submit();
}    		

function ChangePermissions(form)
{
	form.operation.value="ChangePermissions";
	form.submit();
}    