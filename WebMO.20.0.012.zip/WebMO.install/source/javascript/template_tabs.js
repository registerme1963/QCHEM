var bmenuItems =
[
  ["$Templates", "content1"],
  ["Variables",  "content2"],
];

apy_tabsInit();