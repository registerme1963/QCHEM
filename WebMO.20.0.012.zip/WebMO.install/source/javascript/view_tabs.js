var bmenuItems =
[
  ["$Molecule Viewer", "content1"],
  ["Data Viewer",  "content2"]
];

apy_tabsInit();
