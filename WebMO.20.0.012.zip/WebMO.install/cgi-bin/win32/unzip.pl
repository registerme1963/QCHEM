# This script is copyright (c) 2007 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

use Archive::Zip;

my $archive = shift @ARGV;
die "Usage: unzip.pl archive.zip" unless ($archive ne '');

my $zip = new Archive::Zip($archive);
$zip->extractTree();
