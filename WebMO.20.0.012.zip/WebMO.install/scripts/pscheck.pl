# This script is copyright (c) 2016 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

my $globalsFile = shift;
my $psOptions;
my $psRegExp;

print "PSCHECK will attempt to determine your `ps` version\n";

#determine if we are on Linux -- special handling
my $os = `uname`; chomp $os;

if ($os eq 'Linux') {
	#on linux we are able to track cumulative CPU time, including dead child processes -- BONUS!!
	$psOptions = "axj --cumulative";
} else {
	#Determine (as best as possible) if ps wants a Linux-like or BSD-like option string
	$_ = `ps -ef 2>&1`;
	if (/warning/ || /illegal option/) {
		$psOptions = "axj";
	} else {
		$psOptions = "-ef";
	}
}

#get ps output
my @psOutput = `ps $psOptions`;
my %fieldIndex;

$_ = $psOutput[0];
my @fields = split;

for (my $index = 0; $index < @fields; $index++) {
	$fieldIndex{$fields[$index]} = $index;
}

#construct a split statement to parse the ps output
$psRegExp = '(\$ppid, \$pid, \$cpu_time) = (split)' . "[$fieldIndex{PPID}, $fieldIndex{PID}, $fieldIndex{TIME}]";

my $interfaceFile;
open($interfaceFile, "+>>$globalsFile") || die("Cannot open interface file: $! $psRegExp");
seek $interfaceFile, 0, 0;						# rewind

my @contents = <$interfaceFile>;
	
seek $interfaceFile, 0, 0;						# rewind again
truncate $globalsFile, 0;						# empty the file
	
foreach (@contents)
{
	chomp;
	my($variable, $value) = split(/=/, $_, 2);
	
	if ($variable eq "psOptions" || $variable eq "psRegExp") {
		$value = eval("\$$variable");
		$value =~ s/"/ /g;
		$value =~ s/'/\\'/g;
		$value = "\"$value\"";
	}
	
	print $interfaceFile "$variable=$value\n";
}

close($interfaceFile);

print "PSCHECK successful\n";
