# This script is copyright (c) 2006 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

use lib '../cgi-bin';
use lib '../cgi-bin/lib';
use Win32API::File;

local $version;
local $pro;
local $old_version="";
local $userBase="";
local $htmlBase="";
local $cgiBase="";
local $perlPath="";
local $webserver="";
local $host="";
local $psRegExp="(\\\$pid, \\\$ppid, \\\$cpu_time) = /(.{6})(.{7}).{15}(.{10}).*/"; #updated with v8.1
local $license;

umask 0;

#read version
open(temp, "<version");
$version = <temp>;
chomp $version;
close(temp);

#Determine if this is a pro version
#Go ahead and tinker, this only changes what the installer displays, not what
#version you actually get :-)
if ($version =~ /p$/) { $pro = 1; }

#try and find Apache in the root directory
$apacheDir = "c:/";
($apacheDir) = <"$apacheDir/Apache*">;
die "Cannot locate Apache installation directory.\n" unless (-d $apacheDir);

$htmlBase="$apacheDir/htdocs/webmo";
$cgiBase="$apacheDir/cgi-bin/webmo";

local $globals = "$cgiBase/interfaces/globals.int";
die "Cannot located WebMO configuration file.\n" unless (-e $globals);

#parse globals.int
local *handle;
open(handle, "<$globals");

while(<handle>)
{
	chomp;
	local ($variable, $value) = split(/=/, $_, 2);
	
	$_ = $value;
	chop;
	($value) = /\"(.*)/;
	
	$cgiBase = $value		if($variable eq "cgiBase");
	$userBase = $value		if($variable eq "userBase");
	$htmlBase = $value		if($variable eq "htmlBase");
	$old_version = $value	if($variable eq "version");
	$perlPath = $value		if($variable eq "perlPath");
	$webserver = $value		if($variable eq "webserver");
	$host = $value			if($variable eq "host");
	$license = $value		if($variable eq "license");
	
	$sendmailPath = $value	if($variable eq "sendmailPath");
	$zipPath = $value		if($variable eq "zipPath");
	$unzipPath = $value		if($variable eq "unzipPath");
	$ncores = $value		if($variable eq "ncores");
	$jupyterUrl = $value	if($variable eq "jupyterUrl");
}

close(handle);

if ($old_version eq "" || $cgiBase eq "" || $userBase eq "" || $htmlBase eq "")
{
	print "Invalid globals.int file\n";
	print "Exiting upgrade.\n";
	exit(0);
}

#this appears to be the only reliable test for administrative access
my $testFile = "$userBase/testing";
unless (open(handle, ">$testFile")) { print "Cannot write to WebMO installation directory: You must be an administrative user to upgrade WebMO\n."; die; }
close(handle);
unlink("$testFile");

#confirm choices, and begin upgrade
&divider;
print "You have chosen to update from WebMO $old_version to WebMO $version.\n";
print "Continue with upgrade [y/n]:";

local $choice = "";
while ($choice eq "")
{
	local $trial_choice = "";
	$trial_choice = <STDIN>;
	chomp $trial_choice;
	
	if ($trial_choice =~ /^y/i)
	{
		$choice = "y";
	}
	elsif ($trial_choice =~ /^n/i)
	{
		$choice = "n";
	}
}
if ($choice eq "n")
{
	print "Exiting upgrade.\n";
	exit(0);
}

if ($pro && $old_version !~ /p$/)
{
	$license = "";
	
	&divider;
	print "ENTER PRO LICENSE INFORMATION\n\n";
	print "It is time to enter your WebMO Pro license information.\n";
	print "Please enter your license information exactly as it was\n";
	print "received by you when you purchased WebMO Pro.\n\n";

	while ($license eq "")
	{
		print "License number: ";
		local $trial_license = <STDIN>;
		chomp $trial_license;

		if ($trial_license !~ /\d\d\d\d-\d\d\d\d-\d\d\d\d/)
		{
			print "The license must be in the form xxxx-xxxx-xxxx\n";
		}
		else
		{
			# This operation is check-summing your license information to help you catch
			# typographical errors.  Sure, you could easily circumvent it, but why would
			# you want to do that, unless you didn't have a valid license number!?!
		
			local ($first, $second, $third) = split(/-/, $trial_license);
					
			local @checksum = ( (($first*3+7) | ($second*5+13)) % 10, (($first*7+17) & ($second*11+19)) % 10, (($first*13+23) ^ ($second*17+29)) % 10, (($first*19+31) & ($second*23+33) ^ $first) % 10);
		
			$third =~ /(\d)(\d)(\d)(\d)/;
			if ($1 != $checksum[0] || $2 != $checksum[1] || $3 != $checksum[2] || $4 != $checksum[3])
			{
				print "The license number you entered was invalid.\n";
			}
			else
			{
				$license = $trial_license;
			}
		}
	}
}

#setup CGI scripts
print "Setting up CGI scripts...";
#delete the NTFS stream 'Zone.Identifier', which prevents them from being 
#executed without a security dialog if the WebMO archive is downloaded from the #Internet and extracted via Windows explorer
local $executables = "./cgi-bin/win32/*.pl ./cgi-bin/win32/*.exe ./cgi-bin/win32/*.bat";
while (<${executables}>)
{
        Win32API::File::DeleteFile("$_:Zone.Identifier");
}
system("xcopy /e /q /i /y cgi-bin\\win32 \"$cgiBase\\win32\" > NUL");
system("xcopy /e /q /i /y cgi-bin\\lib \"$cgiBase\\lib\" > NUL");
local $scripts = "./cgi-bin/*.{cgi,pm} ./cgi-bin/win32/*.{cgi,pm}";
while (<${scripts}>)
{
	open(script, "<$_");
	local @scriptContents = <script>;
	close(script);

	/cgi\-bin\/(.*)$/;
	open(temp, ">$cgiBase/$1");
	
	print temp "#!$perlPath\n\n";
	print temp "# This script is copyright (c) 2007 by WebMO, LLC, all rights reserved.\n";
	print temp "# Its use is subject to the license agreement that can be found at the following\n";
	print temp "# URL:  http://www.webmo.net/license\n\n";
	
	print temp @scriptContents;
	
	close(temp);
	
	chmod 0755, "$cgiBase/$1";
}

print "finished\n";

#add any new interface files, update old ones (and upgrade batch queues, but not remote servers)
print "Setting up interface files...";
local $interfaceFiles = "./cgi-bin/interfaces/win32/*.int.disabled";
while (<${interfaceFiles}>)
{
	/\/interfaces\/win32\/(.*)\.int\.disabled$/;
	my $queues = "$cgiBase/queues/*";
	my @queueList = <${queues}>;
	$directory = "$cgiBase/interfaces";
	{
		if (-e "$directory/$1.int")
		{
			&update_interface("./cgi-bin/interfaces/$1.int.disabled", "$directory/$1.int");
		}
		elsif (-e "$directory/$1.int.disabled")
		{
			&update_interface("./cgi-bin/interfaces/$1.int.disabled", "$directory/$1.int.disabled");
		}
		else
		{
			system("copy cgi-bin\\interfaces\\$1.int.disabled \"$directory\" > NUL");
			chmod 0777, "$directory/$1.int.disabled";
		}
	}
}

#backup fragment file, if necessary
if (-e "$cgiBase/interfaces/fragments.txt")
{
	my $number = 0;
	while (-e "$cgiBase/interfaces/fragments.$number") { $number++ }
	system("move \"$cgiBase\\interfaces\\fragments.txt\" \"$cgiBase\\interfaces\\fragments.$number\" > NUL");
}
#copy fragments file
system("copy cgi-bin\\interfaces\\fragments.txt \"$cgiBase/interfaces\" > NUL");
chmod 0777, "$cgiBase/interfaces/fragments.txt";

#add any new template files
local $templateFiles = "./cgi-bin/interfaces/*.tmpl";
while (<${templateFiles}>)
{
	/\/interfaces\/(.*)\.tmpl$/;
	#backup any existing templates
	if (-e "$cgiBase/interfaces/$1.tmpl")
	{
		local $number = 0;
		while (-e "$cgiBase/interfaces/$1.$number") { $number++ }
		rename("$cgiBase/interfaces/$1.tmpl", "$cgiBase/interfaces/$1.$number");
	}
	
	system("copy cgi-bin\\interfaces\\$1.tmpl \"$cgiBase/interfaces\" > NUL");
}
#copy over built-in custom variables
system("copy cgi-bin\\interfaces\\*.vars \"$cgiBase\\interfaces\" > NUL");

print "finished\n";

#setup HTML files
print "Setting up HTML source files...";
system("xcopy /e /q /i /y source\\* \"$htmlBase\" > NUL");

print "finished\n";

#update version in globals.int
open(handle, "+>>$globals");
seek handle, 0, 0;						# rewind
	
local @contents = <handle>;
	
seek handle, 0, 0;						# rewind again
truncate $globals, 0;					# empty the file
	
foreach (@contents)
{
	chomp;	
	local($variable, $value) = split(/=/, $_, 2);
	$value = "\"$version\""		if ($variable eq "version");
	$value = "\"$license\""		if ($variable eq "license");
	$value = "\"$psRegExp\""	if ($variable eq "psRegExp");
	print handle "$variable=$value\n";
}
print handle "sendmailPath=\"$cgiBase/win32/sendmail.bat\"\n" unless defined $sendmailPath;
print handle "zipPath=\"$cgiBase/win32/zip.pl\"\n" unless defined $zipPath;
print handle "unzipPath=\"$cgiBase/win32/unzip.pl\"\n" unless defined $unzipPath;
print handle "ncores=\"1\"\n" unless defined $ncores;
print handle "jupyterUrl=\"http://localhost:8888\"\n" unless defined $jupyterUrl;

close(handle);

&divider;
print "WEBMO UPDATE COMPLETE\n\n";

END {
	print "Press <enter> to close window and exit upgrade.\n";
	$_ = <STDIN>;
}

########################################################################
#  Subroutines

sub divider {
	print ">", "=" x 58, "<", "\n";
	print "\n";
}

sub pause
{
print "Enter to continue";
local $temp = <STDIN>;
}

sub complete
{
	local $complete = "\004";
    local $kill     = "\003";	
    local $erase1 =   "\177";
    local $erase2 =   "\010";
    local @cmp_lst;        
    local ($prompt) = @_;        
    local $path = "";
    local $len = 0;
    
    local *dir;
    print($prompt, $path);

	system('stty raw -echo');    
    while (($_ = getc(STDIN)) ne "\r")
    {
    	$path = substr($path, 0, $len);

		$path =~ /(.*)\/[^\/]*$/;
    	$current_path = $1."/";
	    opendir(dir,  $current_path =~ /^[\/.]/ ? $current_path : "./".$current_path);
	    @cmp_lst = readdir(dir);
	    closedir(dir);
			    
	    foreach (@cmp_lst)
	    {
	    	$_ = $current_path.$_;
	    }    	
    	
        # (TAB) attempt completion
        if ($_ eq "\t")
        {
        	@match = grep(/^$path/, @cmp_lst);
            $matches = @match;
            $l = length($test = shift(@match));
            unless ($#match < 0)
            {
				foreach $cmp (@match)
            	{
					until (substr($cmp, 0, $l) eq substr($test, 0, $l))
                	{
                    	$l--;
                    }
                }
                print("\a");
            }
            print($test = substr($test, $len, $l - $len));
            $len = length($path .= $test);
            
            if (-d $path && $matches == 1)
            {
				print "/";
            	$len = length($path .= "/");            	
            }
        }
    	
        # (^D) completion list
        if ($_ eq $complete)
        {
	    	print(join("\r\n", '', grep(/^$path/, @cmp_lst)), "\r\n");
    	    print($prompt, $path);
        };
    
        # (DEL) || (BS) erase
        if ($_ eq $erase1 || $_ eq $erase2)
        {
			if ($len)
        	{
		        print("\b \b");
		        $len--;
		    }
        }
        
        # (^C) kill
        if ($_ eq $kill)
        {
			system('stty -raw echo');
			print "\n";
	       	exit(0);
        }
                
        # printable char
        if (ord >= 32 && $_ ne $erase1)
        {
        	$path .= $_;
        	$len++;
	        print;
        }        
    }
   
    system('stty -raw echo');
    print "\n";
    return $path;
}

sub update_interface
{
	local ($newInterfaceName, $oldInterfaceName) = @_;
	local (*newInterface);
	local (*oldInterface);
	local @oldInterfaceContents;
	local $needNewline;
	open(oldInterface, "+>>$oldInterfaceName");
	seek oldInterface, 0, 0;
	while(<oldInterface>)
	{
		local($variable, $value) = split(/=/, $_, 2);
		push(@oldInterfaceContents, $variable);
		if ($value !~ /\n$/) { $needsNewline = 1; }
	}
	seek oldInterface, 0, 2;
	#add a newline at the end, if neccessary
	if ($needsNewline) {
		print oldInterface "\n";
	}
	#upgrade the interface
	open(newInterface, "<$newInterfaceName");
	while(<newInterface>)
	{
		local($variable, $value) = split(/=/, $_, 2);
		chomp $value;
		if (grep($_ eq $variable, @oldInterfaceContents) == 0)
		{
			print oldInterface "$variable=$value\n";
		}
	}
	close(newInterface);
	close(oldInterface);
}

