# This script is copyright (c) 2006 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

die "USAGE: convert_jobs.pl jobs jobs.db" if (@ARGV != 2);

my ($oldfile, $newfile) = @ARGV;
my $rec_str = "L A32 A64 A32 A10 L A9 c A32 L f c c a1";

open(oldjobs, "<$oldfile");
open(newjobs, ">$newfile");
binmode(newjobs);

while(<oldjobs>)
{
	my($jobNumber, $jobUser, $jobName, $jobDescription, $jobDate, $jobStatus, $pid, $cpu_time, $checkpointFile, $folder) = split(/:/, $_);

	my $server, $engine;
	($server, $pid) = split(/,/, $pid);
	($jobDescription, $engine) = split(/ - /, $jobDescription);
	$engine = lc $engine;
	my ($failureCode) = 32;
	
	print newjobs pack($rec_str, $jobNumber, $jobUser, $jobName, $jobDescription, $engine, $jobDate, $jobStatus, $failureCode, $server, $pid, $cpu_time, $checkpointFile, $folder, "\n");
}

close(oldjobs);
close(newjobs);
