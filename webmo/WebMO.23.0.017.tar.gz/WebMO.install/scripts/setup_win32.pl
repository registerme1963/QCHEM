# This script is copyright (c) 2006 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

use lib '../cgi-bin';
use lib '../cgi-bin/lib';
use Sys::Hostname;
use Win32::TieRegistry;
use Win32API::File;
use Win32::OLE;

local $version;
local $oem;
local $oem_setup_script;
local $pro = 0;
local $license = "";
local $userBase="";
local $htmlBase="";
local $cgiBase="";
local $webserver="autodetect";
local $host=hostname();
local $url_htmlBase="/webmo";
local $url_cgiBase="/cgi-bin/webmo";
local $systemScratch="c:/Windows/temp";
local $perlPath="c:/perl/bin/perl.exe";
local $psRegExp="(\\\$pid, \\\$ppid, \\\$cpu_time) = /(.{6})(.{7}).{15}(.{10}).*/"; #updated with v8.1
local $owner="Computational Chemistry on the WWW";
local $uniqueId=$$;

my $apacheDir = "c:/Program Files/Apache Software Foundation";

umask 0;
$Registry->Delimiter("/");

#read version
open(temp, "<version");
$version = <temp>;
chomp $version;
close(temp);
$oem = $ENV{'WEBMO_OEM'} eq "" ? "webmo" : $ENV{'WEBMO_OEM'};

#Determine if this is a pro version
#Go ahead and tinker, this only changes what the installer displays, not what
#version you actually get :-)
if ($version =~ /p$/) { $pro = 1; }

#find the 'program files' installation directory, using "c:/webmo" if this fails
my $ProgramFilesDir = $Registry->{"LMachine/SOFTWARE/Microsoft/Windows/CurrentVersion/ProgramFilesDir"} || "c:";
$ProgramFilesDir =~ tr/\\/\//;
if (-d "$ProgramFilesDir/WebMO") { die "Previous WebMO installation detected; please run upgrade.pl.\n"; }
mkdir("$ProgramFilesDir/WebMO", 0777) || die "Cannot write to $ProgramFilesDir: You must be an administrative user to install WebMO\n.";
rmdir("$ProgramFilesDir/WebMO");

if ($userBase eq '')
{
	$userBase = "$ProgramFilesDir/WebMO";
}

#check to make sure Perl is installed
$perlPath="c:/strawberry/perl/bin/perl.exe";
unless (-e $perlPath)
{
	die "$perlPath not found; please install Strawberry Perl.\n" unless (-x $perlPath);
}


#try and find Apache in the root directory
$apacheDir = "c:/";
($apacheDir) = <"$apacheDir/Apache*">;
die "Cannot locate Apache installation directory.\n" unless (-d $apacheDir);

$htmlBase="$apacheDir/htdocs/webmo";
$cgiBase="$apacheDir/cgi-bin/webmo";
	
#get license information
&divider;
print "ENTER LICENSE INFORMATION\n\n";
print "It is time to enter your WebMO license information.\n";
print "Please enter your license information exactly as it was\n";
print "received by you.  If you do not yet have a WebMO license\n";
print "number, you can obtain one for free at www.webmo.net, or\n";
print "this script can automatically obtain one for you now.\n\n";

if (!$pro)
{
	print "Have you previously obtained a WebMO license number [y/n]:";
	local $choice = "";
	while ($choice eq "")
	{
		local $trial_choice = "";
		$trial_choice = <STDIN>;
		chomp $trial_choice;
		
		if ($trial_choice =~ /^y/i)
		{
			$choice = "y";
		}
		elsif ($trial_choice =~ /^n/i)
		{
			$choice = "n";
		}
	}
	if ($choice eq "n")
	{
		require("sockets.cgi");
		
		print "Please enter the following information to obtain a license.\n";
		print "A license number will be email to the address provided below.\n";
		print "First name: ";
		my $first = <STDIN>;
		chomp $first;
		$first = escape($first);
		print "Last name: ";
		my $last = <STDIN>;
		chomp $last;
		$last = escape($last);
		print "Affiliation: ";
		my $affiliation = <STDIN>;
		chomp $affiliation;
		$affiliation = escape($affiliation);
		print "Email address: ";
		my $email = <STDIN>;
		chomp $email;
		$email = escape($email);
		my $reference = "$oem - installation";
		$reference = escape($reference);
		
		my $url = "http://www.webmo.net/cgi-bin/get/license.cgi?first=$first&last=$last&affiliation=$affiliation&email=$email&reference=$reference&nocaptcha=true";
		local(*HTTP);
		open_connection(HTTP, "www.webmo.net", "http");
		print HTTP "GET $url\n";
		print HTTP "Host: www.webmo.net\n\n";
		close_connection(HTTP);
		print "\nA license number has been emailed to the address that was specified.\n\n";
	}
}

while ($license eq "")
{
	print "License number: ";
	local $trial_license = <STDIN>;
	chomp $trial_license;

	if ($trial_license !~ /\d\d\d\d-\d\d\d\d-\d\d\d\d/)
	{
		print "The license must be in the form xxxx-xxxx-xxxx\n";
	}
	else
	{
		# This operation is check-summing your license information to help you catch
		# typographical errors.  Sure, you could easily circumvent it, but why would
		# you want to do that, unless you didn't have a valid license number!?!
		
		local ($first, $second, $third) = split(/-/, $trial_license);
				
		local @checksum = ( (($first*3+7) | ($second*5+13)) % 10, (($first*7+17) & ($second*11+19)) % 10, (($first*13+23) ^ ($second*17+29)) % 10, (($first*19+31) & ($second*23+33) ^ $first) % 10);
		
		$third =~ /(\d)(\d)(\d)(\d)/;
		if ($1 != $checksum[0] || $2 != $checksum[1] || $3 != $checksum[2] || $4 != $checksum[3])
		{
			print "The license number you entered was invalid.\n";
		}
		else
		{
			$license = $trial_license;
		}
	}
}

#confirm choices, and begin installation
&divider;
print "Here are the configuration options that you have chosen\n";
print "License number:       $license\n";
print "Path to perl:         $perlPath\n";
print "Webserver name:       $webserver\n";
print "HTML directory:       $htmlBase\n";
print "HTML URL:             $url_htmlBase\n";
print "CGI script directory: $cgiBase\n";
print "CGI script URL:       $url_cgiBase\n";
print "User files directory: $userBase\n\n";
print "Continue with installation [y/n]:";

local $choice = "";

while ($choice eq "")
{
	local $trial_choice = "";
	$trial_choice = <STDIN>;
	chomp $trial_choice;
	
	if ($trial_choice =~ /^y/i)
	{
		$choice = "y";
	}
	elsif ($trial_choice =~ /^n/i)
	{
		$choice = "n";
	}
}
if ($choice eq "n")
{
	print "Exiting installation.\n";
	exit(0);
}

mkdir($htmlBase, 0755);
mkdir($cgiBase, 0755);
mkdir($userBase, 0755);

#setup CGI scripts
print "Setting up CGI scripts...";
#delete the NTFS stream 'Zone.Identifier', which prevents them from being 
#executed without a security dialog if the WebMO archive is downloaded from the
#Internet and extracted via Windows explorer
local $executables = "./cgi-bin/win32/*.pl ./cgi-bin/win32/*.exe ./cgi-bin/win32/*.bat";
while (<${executables}>)
{
	Win32API::File::DeleteFile("$_:Zone.Identifier");
}
system("xcopy /e /q /i /y cgi-bin\\win32 \"$cgiBase\\win32\" > NUL");
system("xcopy /e /q /i /y cgi-bin\\lib \"$cgiBase\\lib\" > NUL");
local $scripts = "./cgi-bin/*.{cgi,pm} ./cgi-bin/win32/*.{cgi,pm}";
while (<${scripts}>)
{
	open(script, "<$_");
	local @scriptContents = <script>;
	close(script);

	/cgi\-bin\/(.*)$/;
	open(temp, ">$cgiBase/$1");
	
	print temp "#!$perlPath\n\n";
	print temp "# This script is copyright (c) 2007 by WebMO, LLC, all rights reserved.\n";
	print temp "# Its use is subject to the license agreement that can be found at the following\n";
	print temp "# URL:  http://www.webmo.net/license\n\n";
	
	print temp @scriptContents;
	
	close(temp);
	
	chmod 0755, "$cgiBase/$1";
}

print "finished\n";

#setup INT files
print "Setting up interface files...";
mkdir "$cgiBase/interfaces", 0777;
system("copy cgi-bin\\interfaces\\win32\\*.int.disabled \"$cgiBase\\interfaces\" > NUL");
system("copy cgi-bin\\interfaces\\*.tmpl \"$cgiBase\\interfaces\" > NUL");
system("copy cgi-bin\\interfaces\\*.vars \"$cgiBase\\interfaces\" > NUL");
system("copy cgi-bin\\interfaces\\fragments.txt \"$cgiBase\\interfaces\" > NUL");
open(temp, ">$cgiBase/interfaces/globals.int");
print temp "version=\"$version\"\n";
print temp "license=\"$license\"\n";
print temp "userBase=\"$userBase\"\n";
print temp "htmlBase=\"$htmlBase\"\n";
print temp "cgiBase=\"$cgiBase\"\n";
print temp "webserver=\"autodetect\"\n";
print temp "webserverProtocol=\"autodetect\"\n";
print temp "host=\"$host\"\n";
print temp "ncores=\"1\"\n";
print temp "url_htmlBase=\"$url_htmlBase\"\n";
print temp "url_cgiBase=\"$url_cgiBase\"\n";
print temp "systemScratch=\"$systemScratch\"\n";
print temp "whereisPath=\"$whereisPath\"\n";
print temp "perlPath=\"$perlPath\"\n";
print temp "psPath=\"$cgiBase/win32/ps.exe\"\n";
print temp "psRegExp=\"$psRegExp\"\n";
print temp "sshPath=\"$ProgramFilesDir/PuTTY/plink.exe\"\n";
print temp "scpPath=\"$ProgramFilesDir/PuTTY/pscp.exe\"\n";
print temp "owner=\"$owner\"\n";
print temp "servers=\"$host,0\"\n";
print temp "externalBatchQueue=\"\"\n";
print temp "externalAuthentication=\"\"\n";
print temp "loginMsg=\"\"\n";
print temp "loginMsgTimestamp=\"\"\n";
print temp "jupyterUrl=\"http://localhost:8888\"\n";
print temp "sudoEnabled=\"\"\n";
print temp "userStorageEnabled=\"\"\n";
print temp "uniqueId=\"$uniqueId\"\n";
print temp "os=\"windows\"\n";
#windows command paths / options
print temp 'catPath="type"', "\n";
print temp 'cpPath="xcopy"', "\n";
print temp 'cpOptions="/e /q /i /y"', "\n";
print temp 'mkdirPath="mkdir"', "\n";
print temp 'mvPath="move"', "\n";
print temp 'rmPath="rmdir"', "\n";
print temp 'rmOptions="/s /q"', "\n";
print temp "sendmailPath=\"$cgiBase/win32/sendmail.bat\"\n";
print temp "tarPath=\"$cgiBase/win32/tar.pl\"\n";
print temp 'tarOptions="cf"', "\n";
print temp "zipPath=\"$cgiBase/win32/zip.pl\"\n";
print temp "unzipPath=\"$cgiBase/win32/unzip.pl\"\n";
close(temp);
#sort it
system("sort \"$cgiBase\\interfaces\\globals.int\" /o \"$cgiBase\\interfaces\\globals.int\"");

local $interfaceFiles = "$cgiBase/interfaces/*.int";
chmod 0777, $_ while (<${interfaceFiles}>);
$interfaceFiles = "$cgiBase/interfaces/*.int.disabled";
chmod 0777, $_ while (<${interfaceFiles}>);
chmod 0777, "$cgiBase/interfaces/fragments.txt";

print "finished\n";

#setup HTML files
print "Setting up HTML source files...";
system("xcopy /e /q /i /y source\\* \"$htmlBase\" > NUL");

print "finished\n";

#setup user directory
print "Setting up user directory...";
open(temp, ">$userBase/log");
close(temp);
chmod 0777, "$userBase/log";
open(temp, ">$userBase/errors");
close(temp);
chmod 0777, "$userBase/errors";
open(temp, ">$userBase/queue");
close(temp);
chmod 0777, "$userBase/queue";

$require++;
require("jobcontrol.cgi");
require("usercontrol.cgi");
require("groupcontrol.cgi");
$require--;
chmod 0777, "$userBase/jobs.db";
chmod 0777, "$userBase/.jobs.index";
chmod 0777, "$userBase/users.db";
chmod 0777, "$userBase/.users.index";
chmod 0777, "$userBase/groups.db";
chmod 0777, "$userBase/.groups.index";

&create_group('webmo');
&create_user('admin', 'webmo', '', 1);
chmod 0777, "$userBase/admin";

my %group_profile;
$group_profile{'timeLimit'} = -1;
$group_profile{'jobTimeLimit'} = -1;
foreach ('enabledInterfaces', 'enabledServers', 'enabledQueues')
{
	$group_profile{$_} = 'all';
}
&set_group_profile('webmo', \%group_profile);

#setup computational servers
mkdir "$cgiBase/servers", 0777;
system("xcopy /e /q /i /y scripts\\findfiles.pl \"$cgiBase\\servers\" > NUL");
system("xcopy /e /q /i /y scripts\\pscheck.pl \"$cgiBase\\servers\" > NUL");

print "finished\n\n";

#setup scratch directory
print "Setting up system scratch directory...";
mkdir "$systemScratch/webmo-$uniqueId", 0777;
print "finished\n";

#copy diagnose.pl and secure.pl scripts
system("copy scripts\\diagnose.pl \"$cgiBase\" > NUL");
system("copy scripts\\secure.pl \"$cgiBase\" > NUL");

print "\nCreate desktop and start menu shortcuts [y/n]:\n";

$choice = "";
while ($choice eq "")
{
	local $trial_choice = "";
	$trial_choice = <STDIN>;
	chomp $trial_choice;
	
	if ($trial_choice =~ /^y/i)
	{
		$choice = "y";
	}
	elsif ($trial_choice =~ /^n/i)
	{
		$choice = "n";
	}
}
if ($choice eq "y")
{
	my $objWSHShell = Win32::OLE->new('WScript.Shell');
	my $iconPath = $htmlBase.'/images/webmo.ico';
	$iconPath =~ s/\//\\/g;

	my $desktopPath = $objWSHShell->SpecialFolders('AllUsersDesktop');
	my $objSC = $objWSHShell->CreateShortcut($desktopPath.'\WebMO login.lnk');
	# Description - Description of the shortcut
	$objSC->{Description} = 'Shortcut to WebMO login page';
	# IconLocation � Path of icon to use for the shortcut file
	$objSC->{IconLocation} = $iconPath;
	# TargetPath = Path to source file or folder
	$objSC->{TargetPath} = "http://localhost${url_cgiBase}/login.cgi";
	$objSC->Save();
	
	my $programsPath = $objWSHShell->SpecialFolders('AllUsersPrograms');
	$objSC = $objWSHShell->CreateShortcut($programsPath.'\WebMO login.lnk');
	# Description - Description of the shortcut
	$objSC->{Description} = 'Shortcut to WebMO login page';
	# IconLocation � Path of icon to use for the shortcut file
	$objSC->{IconLocation} = $iconPath;
	# TargetPath = Path to source file or folder
	$objSC->{TargetPath} = "http://localhost${url_cgiBase}/login.cgi";
	$objSC->Save();	
}

&divider;
print "FINISH SETUP\n\n";
print "The remainder of the WebMO setup will be done through the WebMO\n";
print "administrative tools.  The administrative tools facilitate configuration\n";
print "of system preferences, configuration of any packages (GAMESS, Gaussian,\n";
print "MOPAC, MolPro, NWChem, PC-GAMESS, PQS, QChem, Tinker, etc.), and\n";
print "adding/editing of users.\n\n";

print "Access WebMO with your web browser at the following URL: \n";
print "\thttp://${host}$url_cgiBase/login.cgi\n";
print "or using the desktop / start menu shortcuts.\n\n";

print "Login as the user 'admin' with a blank password. You will be prompted\n";
print "to change your password at that time.  After changing the admin password,\n";
print "you will be prompted to register your copy of WebMO.  You will then be\n";
print "brought to the administration home page.\n\n";
&pause;
print "Click on the 'System Manager' and check the location of the scratch\n";
print "directory, which you may change if desired.  Click 'Return to Admin'\n";
print "to return to the administration home page.\n\n";

print "Click on the 'Interface Manager' and enable the interfaces to any\n";
print "computational chemistry packages that you have already installed on your\n";
print "system by clicking the corresponding 'Enable interface' icon.\n";
print "Configure the interfaces by clicking the 'Edit interface' icon, and make any\n";
print "neccessary changes in the interface configuration, and then click 'Submit'\n";
print "to commit the changes and 'Return' to get back to the Interface Manager.\n";
print "Click 'Return to Admin' to return to the administration home page.\n\n";

print "Click on the 'User Manager' and then the 'New User' button to create WebMO\n";
print "users. Click 'Return to User Manager' to return to the user manager.\n";
print "Click 'Return to Admin' to return to the administration home page.\n\n";

print "Setup is now complete.  Click the 'Logout' button to logout of WebMO.\n";
print "You may now login as a WebMO user and run a test job.\n\n";

END {
	print "Press <enter> to end setup.\n";
	$_ = <STDIN>;
	print "Press <enter> to close window and exit.\n";
	$_ = <STDIN>;
}

########################################################################
#  Subroutines

sub divider {
	print ">", "=" x 58, "<", "\n";
	print "\n";
}

sub pause
{
print "Enter to continue";
local $temp = <STDIN>;
}

sub complete
{
	local $complete = "\004";
    local $kill     = "\003";	
    local $erase1 =   "\177";
    local $erase2 =   "\010";
    local @cmp_lst;        
    local ($prompt) = @_;        
    local $path = "";
    local $len = 0;
    
    local *dir;
    print($prompt, $path);

	system('stty raw -echo');
    while (($_ = getc(STDIN)) ne "\r")
    {
    	$path = substr($path, 0, $len);

		$path =~ /(.*)\/[^\/]*$/;
    	$current_path = $1."/";
	    opendir(dir,  $current_path =~ /^[\/.]/ ? $current_path : "./".$current_path);
	    @cmp_lst = readdir(dir);
	    closedir(dir);
			    
	    foreach (@cmp_lst)
	    {
	    	$_ = $current_path.$_;
	    }    	
    	
        # (TAB) attempt completion
        if ($_ eq "\t")
        {
        	@match = grep(/^$path/, @cmp_lst);
            $matches = @match;
            $l = length($test = shift(@match));
            unless ($#match < 0)
            {
            foreach $cmp (@match)
            	{
					until (substr($cmp, 0, $l) eq substr($test, 0, $l))
                	{
                    	$l--;
                    }
                }
                print("\a");
            }
            print($test = substr($test, $len, $l - $len));
            $len = length($path .= $test);
            
            if (-d $path && $matches == 1)
            {
				print "/";
            	$len = length($path .= "/");            	
            }
        }
    	
        # (^D) completion list
        if ($_ eq $complete)
        {
	    	print(join("\r\n", '', grep(/^$path/, @cmp_lst)), "\r\n");
    	    print($prompt, $path);
        };
    
        # (DEL) || (BS) erase
        if ($_ eq $erase1 || $_ eq $erase2)
        {
			if ($len)
        	{
		        print("\b \b");
		        $len--;
		    }
        }
        
        # (^C) kill
        if ($_ eq $kill)
        {
			system('stty -raw echo');
			print "\n";
	       	exit(0);
        }
                
        # printable char
        if (ord >= 32 && $_ ne $erase1)
        {
        	$path .= $_;
        	$len++;
	        print;
        }
    }
   
    system('stty -raw echo');
    print "\n";
    return $path;
}

sub escape
{
	my ($input) = @_;
	my $string;
	($string = $input) =~ s/([^\w ])/sprintf("%%%02lx", ord($1))/eg;
	#for javascript compatability
	$string =~ s/ /%20/g;
	return $string;
}
