$(function(){
	function loadHelpPage(url) {
		var response = $('<div/>').load(url + ' #main,#title', function( responseText, status, xhr) {
			if (status == 'error') {
				alert('Cannot locate page: ' + url);
				window.history.back();
				return;
			}
			$('#main').replaceWith(response.find('#main'));
			$('#title').replaceWith(response.find('#title'));
			$("#main a").click(linkHandler);
			//handle any deep links to anchor tags
			if (url != null && url.indexOf('#') != -1) {
				var hash = url.substring(url.indexOf('#')+1);
				var anchor = $("a[name="+hash+"]")[0];
				$('#main').scrollTop(anchor.offsetTop);
			}
			updateMenu(url);
		});
	}
	
	function updateMenu(url) {	
		//Highlight the clicked link in the menu
		$("#menu li, #menu h2").removeClass('selected');
		$("#menu li, #menu h2").has('a[href="'+url+'"]').addClass('selected').scrollintoview();
	}
	
	//The click handler for all links
	var linkHandler = function(){
		var url = $(this).attr("href");
		// Load all absolute links normally
		if (url.toLowerCase().lastIndexOf("http",0) == 0)
			return true;
		//Load all mailto links normally
		if (url.toLowerCase().lastIndexOf("mailto",0) == 0)
			return true;
		// Load all relative links in the main div; replace only the id='main'
		loadHelpPage(url);
		window.history.pushState({url: url}, "", url);
		// Prevent browsers default behavior to follow the link when clicked
		return false;
	};
		
	//Make all links on the page into AJAX requests
	$("a").click(linkHandler);
	//Setup forward/back buttons to play nice with AJAX history
	$(window).on("popstate", function(e) {
		var url = window.history.state.url;
		loadHelpPage(url);
	});
	//Push the current / initial state onto the stack
	var url = window.location.href.substring(window.location.href.lastIndexOf("/")+1);
	window.history.pushState({url: url}, "", url);
	//Make sure this link is displayed as selected in the menu
	updateMenu(url);
});
