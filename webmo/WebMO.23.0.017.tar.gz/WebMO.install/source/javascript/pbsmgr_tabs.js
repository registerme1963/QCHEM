var bmenuItems =
[
  ["$Settings", "content1"],
  ["Queues",  "content2"],
];

apy_tabsInit();