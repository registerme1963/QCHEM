var bmenuItems =
[
  ["$Job Options", "content1"],
  ["Advanced",  "content2"],
  ["Preview",  "content4"],
];

apy_tabsInit();