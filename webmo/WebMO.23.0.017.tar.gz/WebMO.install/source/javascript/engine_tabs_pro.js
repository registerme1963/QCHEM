var bmenuItems =
[
  ["$Job Options", "content1"],
  ["Advanced",  "content2"],
  ["Preview",  "content4"],
  ["Notes",  "content5"],
];

apy_tabsInit();