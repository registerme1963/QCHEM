package Logging;

my $LOCK_EX = 2;

my $instance = undef;

sub get_instance {
	$instance = bless {}, shift unless $instance;
    return $instance;
}

sub set_logfile {
	my ($self, $logfilename) = @_;
	$self->{logfilename} = $logfilename;
}

sub log {
	my ($self, $action, $message) = @_;
	
	open(my $handle, ">>", $self->{logfilename});
	flock($handle, $LOG_EX);
	print $handle '[', scalar(localtime), '] ';
	print $handle '[', $action, '] ';
	print $handle "$message\n";
	close($handle);
}


1;