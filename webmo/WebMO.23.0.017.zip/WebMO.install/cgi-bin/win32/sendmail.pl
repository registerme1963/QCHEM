# Modified for Windows to eliminate Net::DNS dependancy by JRS
# David Busby - Edoceo, Inc.

use strict;
use Data::Dumper;
use Net::SMTP;
#use Net::DNS;

# Tell me who root is
use constant ROOT_IS => 'your_email@your_domain.tld';
# Supposed to be for retry count, not implemented
use constant C_RETRY => 0;
# You've seen something like this before
use constant DEBUG => 0;

$!=1;

# Do you want to log what happens?
open (STDOUT,'>NUL');
open (STDERR,'>&STDOUT');

my $buf = do { local ($/); <STDIN>; };

# Parse To Address Header
my $to = '';
if ($buf =~ m/To: (.+)/)
{
  if ($1 eq 'root') { $to = ROOT_IS; }
  else { $to = $1; }
}
if (DEBUG) { print "TO: $to\n"; }
if (!$to) { print STDERR "FATAL: No `To:` address specified\n"; exit(1); }
my ($user,$host) = $to =~ m/(.+)@(.+)/;

my $from = '';
if ($buf =~ m/From: (.+)/)
{
	$from = $1;
}
if (DEBUG) { print "FROM: $from\n"; }
if (!$from) { print STDERR "FATAL: No `From:` address specified\n"; exit(1); }

# Resolve name
#my $res = Net::DNS::Resolver->new(debug => DEBUG);
#my @mx = mx($res,$host);
my $nslookup_info = join('', `nslookup -type=MX $host`);
my @mx = $nslookup_info =~ /mail exchanger = (\S+)/;

if (@mx)
{
  foreach my $rr (@mx)
  {
  	chomp $rr;
    if (DEBUG) { print "MX: ".$rr."\n"; }
    # Send
    # BUG: No error checking or recovery
    my $smtp = Net::SMTP->new($rr, Debug => DEBUG);
    $smtp->mail($from);
    $smtp->to($to);
    $smtp->data($buf);
    $smtp->quit();
    last;
  }
}
else
{
  if (DEBUG) { print "No MX for $host\n"; }
}
exit(0);