# This script is copyright (c) 2007 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

use Archive::Tar;

my $options = shift @ARGV;
my $archive = shift @ARGV;
die "Usage: tar.pl [cf|xf] archive.tar ..." unless (($options eq 'cf' || $options eq 'xf') && $archive ne '');

my $extract = ($options eq 'xf' ? 1 : 0);
my $create = ($options eq 'cf' ? 1 : 0);

my $tar = new Archive::Tar();
$Archive::Tar::DO_NOT_USE_PREFIX = 1;

if ($create)
{
	my @files = @ARGV;
	foreach my $file (@files)
	{
		if (-d $file)
		{
			local(*dir);
			opendir(dir, "$file");
			push(@files, map("$file/$_", grep {!/^\./} readdir(dir)));
			closedir(dir);
		}
	}

	if ($archive eq '-')
	{
		$tar->add_files(@files);
		binmode(STDOUT);
		print STDOUT $tar->write();
	}
	else
	{
		$tar->create_archive($archive, 0, @files);
	}
}
elsif ($extract)
{
	$tar->extract_archive($archive, 0);
}
