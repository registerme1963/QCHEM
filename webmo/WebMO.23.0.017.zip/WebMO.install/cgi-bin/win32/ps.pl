# This script is copyright (c) 2007 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

use Win32::Process::Info;

my $pi = new Win32::Process::Info();
my @info = $pi->GetProcInfo();
my @pids;
foreach my $proc_info (@info)
{
	my $id = $proc_info->{'ProcessId'};
	push(@pids, $id);
	
	$ppid{$id} = $proc_info->{'ParentProcessId'};
	$process{$id} = $proc_info->{'Name'};
	$cputime{$id} = $proc_info->{'KernelModeTime'} + $proc_info->{'UserModeTime'};
	$priority{$id} = $proc_info->{'Priority'};
	$page_faults{$id} = $proc_info->{'PageFaults'};
	$memory{$id} = $proc_info->{'WorkingSetSize'} / 1024;
	$threads{$id} = $proc_info->{'ThreadCount'};
	$virtual_memory{$id} = $proc_info->{'PageFileUsage'} / 1024;
	$creation_date{$id} = $proc_info->{'CreationDate'};
	
	if (length($process{$id}) > 14)
	{
		($process{$id}) = $process{$id} =~ /(.{14})/;
	}
}

print "  PID  PPID Process         CPU-Time     Memory       PF   Virt.Mem Priority Thr\n";
#   0 Idle             20:51:40       16 K        1        0 K Unknown    1
foreach $id (sort { $a <=> $b } @pids)
{
    $ppid = $ppid{$id};
	#make sure ppid is valid
	$ppid = 0 if ($creation_date{$ppid} == 0 || $creation_date{$ppid} > $creation_date{$id});
    
    $seconds = $cputime{$id};
    $hour = int($seconds / 3600);
    $seconds -= $hour * 3600;
    $minute = int($seconds / 60);
    $seconds -= $minute * 60;
    if ($priority{$id} > 15)
    {
        $prio = "Realtime";
    }
    elsif ($priority{$id} > 10 )
    {
        $prio = "High";
    }
    elsif ($priority{$id} > 5 )
    {
        $prio = "Normal";
    }
    elsif ($priority{$id} > 0 )
    {
        $prio = "Low";
    }
    else
    {
        $prio = "Unknown";
    }
    printf("% 5d % 5d %-14s% 4d:%02d:%02d % 8d K % 8d % 8d K %8s % 3d\n",
           $id, $ppid, $process{$id}, $hour, $minute, $seconds,
           $memory{$id}, $page_faults{$id}, $virtual_memory{$id},
           $prio, $threads{$id});
}

