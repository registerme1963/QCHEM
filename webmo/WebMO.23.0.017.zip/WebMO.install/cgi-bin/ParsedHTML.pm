package ParsedHTML;

sub new
{
	return bless {@_};
}

sub _do_parse
{
	my ($this, $filename) = @_;
	
	my $fh;
	open($fh, "<$filename") || return 0;
	while(my $line = <$fh>)
	{
		package main;
		#interpolate any variables
		$line =~ s|<PERL>(.*?)</PERL>|$1|gee;
		#handle any include statements
		my $do_include = ($line =~ s|<PERL\s+SRC=(.*?)></PERL>|$1|gee);
		if ($do_include)
		{
			my $include = $line;
			#trim
			$include =~ s/^\s*(\S*)\s*$/$1/;
			my $dir = File::Basename::dirname($filename);
			$include = "$dir/$include" unless ($include =~ m|^/|);
			$this->_do_parse($include);
		}
		else
		{
			print $line;
		}
	}
	close($fh);
}

sub parse
{
	my ($this, $filename) = @_;
	
	print "Content-type:  text/html\n";
	print "Pragma: no-cache\n\n";
	
	$this->_do_parse($filename);
	
	return 1;
}

sub parse_to_file
{
	my ($this, $filename, $dest) = @_;

	#dup STDOUT to save it
	local *SAVOUT;
	open(SAVOUT, ">&STDOUT");
	open(STDOUT, ">$dest");
	
	$this->_do_parse($filename);

	close(STDOUT);
	open(STDOUT, ">&SAVOUT");
	
	return 1;
}

1;