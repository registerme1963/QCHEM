package PAMShadow;

use base 'Authen::Simple::Adapter';

&main::load_interface("interfaces/authen.conf");

my $sudoPath = $main::sudoPath;
my $script_location = $main::pamShadowScriptLocation;

die "sudo not located at $sudoPath; please edit globals.int appropriately" unless (-e $sudoPath);
die "pam_authenticate.pl not located at $script_location or not executable; please edit authen.conf appropriately" unless (-x $script_location);

sub check()
{
	my ($self, $username, $password) = @_;
	#Note that you might have to change the following line to refelect to proper location
	#of the pam_authenticate.pl script.  The script can be found in the WebMO cgi-bin
	#directory, or in the WebMO installation files.  You will also need to allow
	#passwordless sudo execution of the script by user 'webmo'.
	local(*handle);
	open(handle, "| $sudoPath $script_location");
	print handle "$username\n";
	print handle "$password\n";
	close(handle);
	return (my $retval = (($? >> 8) == 1));
}
