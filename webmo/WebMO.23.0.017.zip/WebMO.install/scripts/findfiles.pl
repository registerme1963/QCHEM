# This script is copyright (c) 2006 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

local $globalsFile = shift;
local *interfaceFile;

local %globals;
if (-e $globalsFile)
{
	open(interfaceFile, "<$globalsFile");
	while(<interfaceFile>)
	{
		chomp;
		local($variable, $value) = split(/=/, $_, 2);
		$value =~ s/^"(.*)"$/$1/;
		$globals{"$variable"}=$value;
	}
	close(interfaceFile);
}

#locate whereis for use in installation
local @instances;
if ($globals{'whereisPath'} eq "")
{
	&find_system_file("whereis", *instances);
	if (@instances > 0)
	{
		$globals{'whereisPath'} = $instances[0];
	}
	else
	{
		print "The utility 'whereis' could not be located because it is not in your\n";
		print "current path. To continue the installation, edit open setup.pl in your\n";
		print "text editor and change the following line near the beginning of the script:\n\n";
		print "'local \$perlPath = \"\";' to read 'local \$perlPath = \"/usr/bsd/whereis\";'\n";
		print "substituting /usr/bsd/whereis for the path to 'whereis' on your system.\n";
		exit(0);
	}
}

&guess_system_file("perl");
&guess_system_file("tar");
&add_options("tar", "cf");
&guess_system_file("zip");
&add_options("zip", "-r -q");
&guess_system_file("unzip");
&guess_system_file("ps");
&add_options("ps", "");
&guess_system_file("sendmail");
&add_options("sendmail", "-t");
&guess_system_file("rsh");
&guess_system_file("rcp");
&guess_system_file("ssh");
&add_options("ssh", "");
&guess_system_file("scp");
&add_options("scp", "");
&guess_system_file("cp");
&add_options("cp", "-r");
&guess_system_file("mv");
&guess_system_file("kill");
&guess_system_file("cat");
&guess_system_file("rm");
&add_options("rm", "-rf");
&guess_system_file("mkdir");
&guess_system_file("uname");
&guess_system_file("sudo");
&guess_system_file("chown");
&guess_system_file("chmod");
&guess_system_file("zcat");
&guess_system_file("wget");
&add_options("wget", "-q -O");
&guess_system_file("curl");
&add_options("curl", "-s -o");

open(interfaceFile, ">$globalsFile");
foreach (sort keys %globals)
{
	print interfaceFile "$_=\"$globals{$_}\"\n";
}
close(interfaceFile);

########################################################################
#  Subroutines

sub guess_system_file
{
	local($systemFile) = @_;
	local @list;
	&find_system_file($systemFile, *list);
	if ($globals{"${systemFile}Path"} eq "" ) { $globals{"${systemFile}Path"} = $list[0]; }
}

sub add_options
{
	local ($systemFile, $options) = @_;
	if ($globals{"${systemFile}Options"} eq "" ) { $globals{"${systemFile}Options"} = $options; }
}

sub find_system_file
{
	local($systemFile, *list) = @_;	
	local $output = `whereis $systemFile`;
	$output = `which $systemFile` if ($output eq '');

	@list = ();

	$output =~ tr/\n/ /;
	if ($output =~ /$systemFile: (.*)/)
	{
		$output = $1;
	}
	
	local @options = split(/\s+/, $output);
	foreach (@options)
	{
		if (/$systemFile$/)
		{
			push @list, $_;
		}
	}
}

