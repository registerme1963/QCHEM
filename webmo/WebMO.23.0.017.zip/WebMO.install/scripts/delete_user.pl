# This script is copyright (c) 2015 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

# attempt to set the library path around the location of THIS script
# so that we can use SimpleDB
use FindBin;
use lib "$FindBin::Bin";
use lib "$FindBin::Bin/../cgi-bin";

use SimpleDB;

die "Usage: delete_user.pl username\n" unless (@ARGV == 1);
my ($jobs_db_filename, $jobs_index_filename) = ("jobs.db", ".jobs.index");
my ($users_db_filename, $users_index_filename) = ("users.db", ".users.index");
my ($username, $deleteFiles) = ($ARGV[0], 1);

my @jobs_db_fields = ('jobNumber', 'jobUser', 'jobName', 'jobDescription', 'jobEngine', 'binaryDate', 'jobStatus', 'failureCode',
				'server', 'pid', 'cpu_time', 'checkpointFile', 'folder', 'newline');
my $jobs_db_rec_format = 'L A32 A64 A32 A10 L A9 c A32 L f c c a1';
my $jobs_db = new SimpleDB($jobs_db_filename, $jobs_index_filename, \@jobs_db_fields, $jobs_db_rec_format, 'jobNumber');

@users_db_fields = ('username', 'group', 'isAdministrator', 'enabled', 'password', 'sessionId', 'profile', 'newline');
my $users_db_rec_format = 'A32 A32 c c A13 A13 A2048 a1';
my $users_db = new SimpleDB($users_db_filename, $users_index_filename, \@users_db_fields, $users_db_rec_format, 'username');

my (@records) = ($users_db->find_record_by_key($username));
die "Cannot find user: $username" if ($records[0] == -1);
$users_db->purge_records(@records);

print "Deleting user: $username\n";
	
if ($deleteFiles)
{
	my ($DIR);
	opendir($DIR, "./$username");
	my @jobs = readdir($DIR);
	closedir($DIR);

	foreach my $jobNumber (@jobs)
	{
		next if ($jobNumber eq '.');
		next if ($jobNumber eq '..');
		next if (!(-d "./$username/$jobNumber"));
		
		print "Deleting job number: $jobNumber\n";
		
		my %jobInfo;
		my $job_record = $jobs_db->find_record_by_key($jobNumber);
		next if ($job_record == -1);
		$jobs_db->fetch_record($job_record, \%jobInfo);		
		$jobInfo{'jobStatus'} = "deleted";
		$jobs_db->update_record($job_record, \%jobInfo);
	}
	
	system("rm -rf ./$username");
}
exit(0);