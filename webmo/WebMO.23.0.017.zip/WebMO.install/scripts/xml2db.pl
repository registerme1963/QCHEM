# This script is copyright (c) 2007 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

# attempt to set the library path around the location of THIS script
# so that we can use SimpleDB
use FindBin;
use lib "$FindBin::Bin";
use lib "$FindBin::Bin/../cgi-bin";

use XML::Simple;
use SimpleDB;

my $interactive = 0;
my $xml_file = shift;
my $xml_type = lc shift;

$interactive = 1 if ($xml_file eq "" || $xml_type eq "");

if ($interactive)
{
	print "\n";
	print "WELCOME TO WEBMO XML DATABASE UTILITY\n\n";
	print "This utility will translate your WebMO jobs/users/groups XML\n";
	print "files back into valid WebMO databaes.  This can be used for\n";
	print "repair or modification of the binary WebMO databases.\n";
	&pause;

	if ($xml_file eq "") {
		&divider;
		print "Please locate the XML file that you wish to convert.\n\n";
	}

	while ($xml_file eq "")
	{
		my $trial_xml_file = &complete("Location: ");
		chomp $trial_xml_file;

		if (!(-f $trial_xml_file))
		{
			print "That file does not exist.\n";
		}
		else
		{
			$xml_file = $trial_xml_file;
		}
	}
	
	if ($xml_type eq "") {
		&divider;
		print "Please select the database you wish to create:\n";
		print "1) jobs.db\n";
		print "2) users.db\n";
		print "3) groups.db\n";
	}
	
	while ($xml_type eq "")
	{
		my $trial_xml_type = <STDIN>;
		chomp $trial_xml_type;

		if ($trial_xml_type < 1 || $trial_xml_type > 3)
		{
			print "Invalid selection.\n";
		}
		else
		{
			$xml_type = "jobs" if ($trial_xml_type == 1);
			$xml_type = "users" if ($trial_xml_type == 2);
			$xml_type = "groups" if ($trial_xml_type == 3);
		}
	}	
}

my $db_file = "$xml_type.db";
die "$xml_type.db file already exists" if (-e $db_file);

my @db_fields;
my $db_rec_format;
my $db_ref;
my $root;
my $keyattr;

#handle jobs.db
if ($xml_type eq 'jobs')
{
	@db_fields = ('jobNumber', 'jobUser', 'jobName', 'jobDescription', 'jobEngine', 'binaryDate', 'jobStatus', 'failureCode',
		'server', 'pid', 'cpu_time', 'checkpointFile', 'folder', 'newline');
	$db_rec_format = 'L A32 A64 A32 A10 L A9 c A32 L f c c a1';
	$db_ref = new SimpleDB($db_file, "/dev/null", \@db_fields, $db_rec_format, 'jobNumber');
	$root = 'jobs_db';
	$keyattr = 'jobNumber';
}
# handle users.db
elsif ($xml_type eq 'users')
{
	@db_fields = ('username', 'group', 'isAdministrator', 'enabled', 'password', 'sessionId', 'profile', 'newline');
	$db_rec_format = 'A32 A32 c c A13 A13 A2048 a1';
	$db_ref = new SimpleDB($db_file, "/dev/null", \@db_fields, $db_rec_format, 'username');
	$root = 'users_db';
	$keyattr = 'username';
}
# handle $groups.db
elsif ($xml_type eq 'groups')
{
	@db_fields = ('group', 'profile', 'newline');
	$db_rec_format = 'A32 A2048 a1';
	$db_ref = new SimpleDB($db_file, "/dev/null", \@db_fields, $db_rec_format, 'group');
	$root = 'groups_db';
	$keyattr = 'group';
}
else
{
	die "Unknown database";
}

# read in the XML
my $key_name = $xml_type; chop $key_name; $key_name .= "_entry";
my $xs = new XML::Simple(ForceArray => ['job_entry', 'user_entry', 'group_entry']);
my $xml = $xs->XMLin($xml_file);

if ($interactive)
{
	print "\nWriting output to $xml_type.db.  Make sure to delete the existing\n";
	print "database index, a hidden file, .$xml_type.index, before utilizing\n";
	print "the new database file within WebMO.\n";
}

my $records = $xml->{$key_name};
for (my $record = 0; $record < @{$records}; $record++)
{
	my $data = $records->[$record];
	$data->{'newline'} = "\n";
	if ($data->{'profile'} ne "")
	{
		$data->{'profile'} = join(chr(0), @{$data->{profile}->{profile_entry}});
	}
	$db_ref->create_record($data);
}

########################################################################
#  Subroutines

sub divider {
	print ">", "=" x 58, "<", "\n";
	print "\n";
}

sub pause
{
print "Enter to continue";
local $temp = <STDIN>;
}

sub complete
{
	local $complete = "\004";
    local $kill     = "\003";	
    local $erase1 =   "\177";
    local $erase2 =   "\010";
    local @cmp_lst;        
    local ($prompt) = @_;        
    local $path = "";
    local $len = 0;
    
    local *dir;
    print($prompt, $path);

	system('stty raw -echo');    
    while (($_ = getc(STDIN)) ne "\r")
    {
    	$path = substr($path, 0, $len);

		$path =~ /(.*)\/[^\/]*$/;
    	$current_path = $1."/";
	    opendir(dir,  $current_path =~ /^[\/.]/ ? $current_path : "./".$current_path);
	    @cmp_lst = readdir(dir);
	    closedir(dir);
			    
	    foreach (@cmp_lst)
	    {
	    	$_ = $current_path.$_;
	    }    	
    	
        # (TAB) attempt completion
        if ($_ eq "\t")
        {
        	@match = grep(/^$path/, @cmp_lst);
            $matches = @match;
            $l = length($test = shift(@match));
            unless ($#match < 0)
            {
				foreach $cmp (@match)
            	{
					until (substr($cmp, 0, $l) eq substr($test, 0, $l))
                	{
                    	$l--;
                    }
                }
                print("\a");
            }
            print($test = substr($test, $len, $l - $len));
            $len = length($path .= $test);
            
            if (-d $path && $matches == 1)
            {
				print "/";
            	$len = length($path .= "/");            	
            }
        }
    	
        # (^D) completion list
        if ($_ eq $complete)
        {
	    	print(join("\r\n", '', grep(/^$path/, @cmp_lst)), "\r\n");
    	    print($prompt, $path);
        };
    
        # (DEL) || (BS) erase
        if ($_ eq $erase1 || $_ eq $erase2)
        {
			if ($len)
        	{
		        print("\b \b");
		        $len--;
		    }
        }
        
        # (^C) kill
        if ($_ eq $kill)
        {
			system('stty -raw echo');
			print "\n";
	       	exit(0);
        }
                
        # printable char
        if (ord >= 32 && $_ ne $erase1)
        {
        	$path .= $_;
        	$len++;
	        print;
        }        
    }
   
    system('stty -raw echo');
    print "\n";
    return $path;
}
