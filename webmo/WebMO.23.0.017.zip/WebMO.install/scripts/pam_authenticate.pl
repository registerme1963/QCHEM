#!/usr/bin/perl

use Authen::Simple::PAM;
$auth = Authen::Simple::PAM->new();

my $username = <>; chomp $username;
my $password = <>; chomp $password;

exit($auth->authenticate($username, $password));

