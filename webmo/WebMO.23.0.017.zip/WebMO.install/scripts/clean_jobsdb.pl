# This script is copyright (c) 2012 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

# attempt to set the library path around the location of THIS script
# so that we can use SimpleDB
use FindBin;
use lib "$FindBin::Bin";
use lib "$FindBin::Bin/../cgi-bin";

use SimpleDB;

die "Usage: clean_jobsdb.pl <jobs.db> <deleted_jobs.db>\n" unless (@ARGV == 2);
my ($jobs_db_filename, $deleted_db_filename) = @ARGV;
my ($jobs_db_index) = $jobs_db_filename;
my ($deleted_db_index) = $deleted_db_filename;
$jobs_db_index=~ s/jobs\.db/\.jobs\.index/;
my ($jobs_dir) = $jobs_db_filename;
$jobs_dir=~ s/jobs\.db//;
$jobs_dir="." if ($jobs_dir eq '');

die "$deleted_db_filename already exists; please remove it.\n" if (-e $deleted_db);
die "$jobs_db_filename.bak already exists; please remove it.\n" if (-e $jobs_db_filename.bak);

chdir($jobs_dir);
die "This script must be executed on jobs.db within <webmouser_dir>" unless (-e "users.db");

#do a backup
system("cp $jobs_db_filename $jobs_db_filename.bak");

my @db_fields = ('jobNumber', 'jobUser', 'jobName', 'jobDescription', 'jobEngine', 'binaryDate', 'jobStatus', 'failureCode',
				'server', 'pid', 'cpu_time', 'checkpointFile', 'folder', 'newline');
my $db_rec_format = 'L A32 A64 A32 A10 L A9 c A32 L f c c a1';
my $jobs_db = new SimpleDB($jobs_db_filename, $jobs_db_index, \@db_fields, $db_rec_format, 'jobNumber');

my $record_count = $jobs_db->get_record_count();
my $deleted_db = new SimpleDB($deleted_db_filename, "/dev/null", $jobs_db->{fields}, $jobs_db->{rec_format}, $jobs_db->{index_field});

my %jobInfo;
my @purged_records;
for (my $record = 1; $record <= $record_count - 50; $record++)
{
	$jobs_db->fetch_record($record, \%jobInfo);
	if ($jobInfo{'jobStatus'} eq 'deleted')
	{
		push(@purged_records, $record);
		$deleted_db->create_record(\%jobInfo);
	} elsif (!(-d "$jobs_dir/$jobInfo{'jobUser'}/$jobInfo{'jobNumber'}"))
	{
		push(@purged_records, $record);
		$deleted_db->create_record(\%jobInfo);
	}
}
$jobs_db->purge_records(@purged_records);

print "Removed ", scalar(@purged_records), " records\n";
exit(0);
