# This script is copyright (c) 2007 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

# attempt to set the library path around the location of THIS script
# so that we can use SimpleDB
use FindBin;
use lib "$FindBin::Bin";
use lib "$FindBin::Bin/../cgi-bin";

use XML::Simple;
use SimpleDB;

my $interactive = 0;
my $db_file = shift;
my $db_type = lc shift;

$interactive = 1 if ($db_file eq "" || $db_type eq "");

if ($interactive)
{
	print "\n";
	print "WELCOME TO WEBMO XML DATABASE UTILITY\n\n";
	print "This utility will translate your WebMO jobs/users/groups databases\n";
	print "into easily human readable/editable XML.  This can be used for\n";
	print "repair or modification of the binary WebMO databases.\n";
	&pause;

	if ($db_file eq "") {
		&divider;
		print "Please locate the database file that you wish to convert.\n\n";
	}

	while ($db_file eq "")
	{
		my $trial_db_file = &complete("Location: ");
		chomp $trial_db_file;

		if (!(-f $trial_db_file))
		{
			print "That file does not exist.\n";
		}
		else
		{
			$db_file = $trial_db_file;
		}
	}
	
	if ($db_type eq "") {
		&divider;
		print "Please select the database you wish to convert:\n";
		print "1) jobs.db\n";
		print "2) users.db\n";
		print "3) groups.db\n";
	}
	
	while ($db_type eq "")
	{
		my $trial_db_type = <STDIN>;
		chomp $trial_db_type;

		if ($trial_db_type < 1 || $trial_db_type > 3)
		{
			print "Invalid selection.\n";
		}
		else
		{
			$db_type = "jobs" if ($trial_db_type == 1);
			$db_type = "users" if ($trial_db_type == 2);
			$db_type = "groups" if ($trial_db_type == 3);
		}
	}	
}

my @db_fields;
my $db_rec_format;
my $db_ref;
my $root;
my $keyattr;
my $debug = 1;

#handle jobs.db
if ($db_type eq 'jobs')
{
	@db_fields = ('jobNumber', 'jobUser', 'jobName', 'jobDescription', 'jobEngine', 'binaryDate', 'jobStatus', 'failureCode',
		'server', 'pid', 'cpu_time', 'checkpointFile', 'folder', 'newline');
	$db_rec_format = 'L A32 A64 A32 A10 L A9 c A32 L f c c a1';
	$db_ref = new SimpleDB($db_file, "/dev/null", \@db_fields, $db_rec_format, 'jobNumber', $debug);
	$root = 'jobs_db';
	$keyattr = 'jobNumber';
}
# handle users.db
elsif ($db_type eq 'users')
{
	@db_fields = ('username', 'group', 'isAdministrator', 'enabled', 'password', 'sessionId', 'profile', 'newline');
	$db_rec_format = 'A32 A32 c c A13 A13 A2048 a1';
	$db_ref = new SimpleDB($db_file, "/dev/null", \@db_fields, $db_rec_format, 'username', $debug);
	$root = 'users_db';
	$keyattr = 'username';
}
# handle $groups.db
elsif ($db_type eq 'groups')
{
	@db_fields = ('group', 'profile', 'newline');
	$db_rec_format = 'A32 A2048 a1';
	$db_ref = new SimpleDB($db_file, "/dev/null", \@db_fields, $db_rec_format, 'group', $debug);
	$root = 'groups_db';
	$keyattr = 'group';
}
else
{
	die "Unknown database";
}

# slurp in all the records
my @records;
my $record_count = $db_ref->get_record_count();
for (my $record = 1; $record <= $record_count; $record++)
{
	my %data;
	$db_ref->fetch_record($record, \%data);

	# data cleanup
	if ($data{'profile'} ne "")
	{
		my @profile_entries = split(/\0/, $data{'profile'});
		$data{'profile'} = { 'profile_entry' => \ @profile_entries };
	}
	delete($data{'newline'});
	
	push (@records, \%data);
}

# write out the XML
my $key_name = $db_type; chop $key_name; $key_name .= "_entry";
my $xs = new XML::Simple(RootName=>$root,KeyAttr=>$keyattr);
my $xml = $xs->XMLout( { "$key_name" => \@records } );

if ($interactive)
{
	print "\nWriting output to $db_type.xml\n";
	my $fh;
	open ($fh, ">$db_type.xml");
	print $fh $xml;
	close($fh);
}
else
{
	print $xml;
}

########################################################################
#  Subroutines

sub divider {
	print ">", "=" x 58, "<", "\n";
	print "\n";
}

sub pause
{
print "Enter to continue";
local $temp = <STDIN>;
}

sub complete
{
	local $complete = "\004";
    local $kill     = "\003";	
    local $erase1 =   "\177";
    local $erase2 =   "\010";
    local @cmp_lst;        
    local ($prompt) = @_;        
    local $path = "";
    local $len = 0;
    
    local *dir;
    print($prompt, $path);

	system('stty raw -echo');    
    while (($_ = getc(STDIN)) ne "\r")
    {
    	$path = substr($path, 0, $len);

		$path =~ /(.*)\/[^\/]*$/;
    	$current_path = $1."/";
	    opendir(dir,  $current_path =~ /^[\/.]/ ? $current_path : "./".$current_path);
	    @cmp_lst = readdir(dir);
	    closedir(dir);
			    
	    foreach (@cmp_lst)
	    {
	    	$_ = $current_path.$_;
	    }    	
    	
        # (TAB) attempt completion
        if ($_ eq "\t")
        {
        	@match = grep(/^$path/, @cmp_lst);
            $matches = @match;
            $l = length($test = shift(@match));
            unless ($#match < 0)
            {
				foreach $cmp (@match)
            	{
					until (substr($cmp, 0, $l) eq substr($test, 0, $l))
                	{
                    	$l--;
                    }
                }
                print("\a");
            }
            print($test = substr($test, $len, $l - $len));
            $len = length($path .= $test);
            
            if (-d $path && $matches == 1)
            {
				print "/";
            	$len = length($path .= "/");            	
            }
        }
    	
        # (^D) completion list
        if ($_ eq $complete)
        {
	    	print(join("\r\n", '', grep(/^$path/, @cmp_lst)), "\r\n");
    	    print($prompt, $path);
        };
    
        # (DEL) || (BS) erase
        if ($_ eq $erase1 || $_ eq $erase2)
        {
			if ($len)
        	{
		        print("\b \b");
		        $len--;
		    }
        }
        
        # (^C) kill
        if ($_ eq $kill)
        {
			system('stty -raw echo');
			print "\n";
	       	exit(0);
        }
                
        # printable char
        if (ord >= 32 && $_ ne $erase1)
        {
        	$path .= $_;
        	$len++;
	        print;
        }        
    }
   
    system('stty -raw echo');
    print "\n";
    return $path;
}
