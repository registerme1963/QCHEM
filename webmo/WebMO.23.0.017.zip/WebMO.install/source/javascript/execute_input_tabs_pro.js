var bmenuItems =
[
  ["$Input File", "content1"],
  ["Choose Engine",  "content2"],
  ["Notes",  "content3"],
];

apy_tabsInit();
