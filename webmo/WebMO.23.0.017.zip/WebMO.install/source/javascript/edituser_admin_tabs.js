var bmenuItems =
[
  ["$Password", "content1"],
  ["Preferences",  "content2"],
  ["Permissions",  "content3"],
];

apy_tabsInit();