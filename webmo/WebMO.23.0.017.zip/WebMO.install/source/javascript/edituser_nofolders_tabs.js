var bmenuItems =
[
  ["$Password", "content1"],
  ["Preferences",  "content2"],
];

apy_tabsInit();