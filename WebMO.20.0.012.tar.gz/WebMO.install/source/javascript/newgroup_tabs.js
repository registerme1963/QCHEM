var bmenuItems =
[
  ["$Password",  "content1"],
  ["Permissions",  "content2"],
];

apy_tabsInit();