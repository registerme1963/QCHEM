# This script is copyright (c) 2009 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

my $globals = shift;

# read the path to globals.int on the command line if its there
$interactive = 1 if ($globals eq "");

# try to find globals.int ourself
$globals = "./interfaces/globals.int" if (-e "./interfaces/globals.int");

print "\n";
print "WELCOME TO WEBMO CLONE INTERFACE UTILITY\n\n";
print "This utility will make a copy of an existing interface to\n";
print "a computational engine, under a new name.  This can be used\n";
print "as a starting point for developing support for a new computational\n";
print "engine, or for supporting multiple version of the same engine.\n\n";
&pause;

#ask the user to locate globals.int
if ($globals eq "") {
	&divider;
	print "Please locate the globals.int file.  This file is installed in the location\n";
	print "<webmo>/cgi-bin/interfaces/globals.int\n\n";
}

while ($globals eq "")
{
	my $trial_globals = &complete("Location: ");
	chomp $trial_globals;
	if (!(-f $trial_globals))
	{
		print "That file does not exist.\n";
	}
	else
	{
		$globals = $trial_globals;
	}
}

#parse globals.int
local *handle;
open(handle, "<$globals");
while(<handle>)
{
	chomp;
	my ($variable, $value) = split(/=/, $_, 2);
	my $expression = "\$$variable=$value;";
	eval $expression;
}
close(handle);

print "Enter the name of the engine you wish to clone (e.g. gaussian): ";
my $cloned_engine = <>;
chomp $cloned_engine;
die "Could not locate $cloned_engine.int" unless (-e "$cgiBase/interfaces/$cloned_engine.int" || -e "$cgiBase/interfaces/$cloned_engine.int.disabled");

print "Enter the name of the NEW engine you wish to create (e.g. gaussian09): ";
my $new_engine = <>;
chomp $new_engine;

#now copy the files
system("cp $cgiBase/interfaces/$cloned_engine.int  $cgiBase/interfaces/$new_engine.int.disabled >& /dev/null");
system("cp $cgiBase/interfaces/$cloned_engine.int.disabled  $cgiBase/interfaces/$new_engine.int.disabled >& /dev/null");
system("cp $cgiBase/interfaces/$cloned_engine.tmpl  $cgiBase/interfaces/$new_engine.tmpl >& /dev/null");

system("cp $cgiBase/$cloned_engine.cgi  $cgiBase/$new_engine.cgi >& /dev/null");
system("cp $cgiBase/${cloned_engine}mgr_admin.cgi  $cgiBase/${new_engine}mgr_admin.cgi >& /dev/null");
system("cp $cgiBase/parse_${cloned_engine}.cgi  $cgiBase/parse_${new_engine}.cgi >& /dev/null");
system("cp $cgiBase/run_${cloned_engine}.cgi  $cgiBase/run_${new_engine}.cgi >& /dev/null");

system("cp $htmlBase/$cloned_engine.html  $htmlBase/$new_engine.html >& /dev/null");
system("cp $htmlBase/javascript/$cloned_engine.js  $htmlBase/javascript/$new_engine.js >& /dev/null");
system("cp $htmlBase/${cloned_engine}mgr_admin.html  $htmlBase/${new_engine}mgr_admin.html >& /dev/null");

#change references from the cloned engine to the new one
my $replacement_command = "perl -pi -e 's/$cloned_engine/$new_engine/g'";
system("$replacement_command $cgiBase/interfaces/$new_engine.int.disabled >& /dev/null");
system("$replacement_command $cgiBase/$new_engine.cgi >& /dev/null");
system("$replacement_command $cgiBase/${new_engine}mgr_admin.cgi >& /dev/null");
system("$replacement_command $cgiBase/parse_${new_engine}.cgi >& /dev/null");
system("$replacement_command $cgiBase/run_${new_engine}.cgi >& /dev/null");
system("$replacement_command $htmlBase/$new_engine.html >& /dev/null");
system("$replacement_command $htmlBase/javascript/$new_engine.js >& /dev/null");
system("$replacement_command $htmlBase/${new_engine}mgr_admin.html >& /dev/null");

print "\n\nYou should now hand-edit the file:\n";
print "\t$cgiBase/interfaces/$new_engine.int.disabled\n";
print "to reflect a new displayed name (e.g. Gaussian09) and description for this interface\n";
print "to distinguish it from any other similar interfaces from which it was cloned from.  Of course\n";
print "if you are implementing a completely NEW interface, it will be necessary to update these\n";
print "scripts as appropriate for the new engine\n\n";

#check for remote servers
if (split(/:/, $servers) > 1)
{
	print "************************************************\n";
	print "You should delete/re-add all remote servers NOW!\n";
	print "************************************************\n\n";
}

########################################################################
#  Subroutines

sub divider {
	print ">", "=" x 58, "<", "\n";
	print "\n";
}

sub pause
{
print "Enter to continue";
local $temp = <STDIN>;
}

sub complete
{
	local $complete = "\004";
    local $kill     = "\003";	
    local $erase1 =   "\177";
    local $erase2 =   "\010";
    local @cmp_lst;        
    local ($prompt) = @_;        
    local $path = "";
    local $len = 0;
    
    local *dir;
    print($prompt, $path);

	system('stty raw -echo');    
    while (($_ = getc(STDIN)) ne "\r")
    {
    	$path = substr($path, 0, $len);

		$path =~ /(.*)\/[^\/]*$/;
    	$current_path = $1."/";
	    opendir(dir,  $current_path =~ /^[\/.]/ ? $current_path : "./".$current_path);
	    @cmp_lst = readdir(dir);
	    closedir(dir);
			    
	    foreach (@cmp_lst)
	    {
	    	$_ = $current_path.$_;
	    }    	
    	
        # (TAB) attempt completion
        if ($_ eq "\t")
        {
        	@match = grep(/^$path/, @cmp_lst);
            $matches = @match;
            $l = length($test = shift(@match));
            unless ($#match < 0)
            {
				foreach $cmp (@match)
            	{
					until (substr($cmp, 0, $l) eq substr($test, 0, $l))
                	{
                    	$l--;
                    }
                }
                print("\a");
            }
            print($test = substr($test, $len, $l - $len));
            $len = length($path .= $test);
            
            if (-d $path && $matches == 1)
            {
				print "/";
            	$len = length($path .= "/");            	
            }
        }
    	
        # (^D) completion list
        if ($_ eq $complete)
        {
	    	print(join("\r\n", '', grep(/^$path/, @cmp_lst)), "\r\n");
    	    print($prompt, $path);
        };
    
        # (DEL) || (BS) erase
        if ($_ eq $erase1 || $_ eq $erase2)
        {
			if ($len)
        	{
		        print("\b \b");
		        $len--;
		    }
        }
        
        # (^C) kill
        if ($_ eq $kill)
        {
			system('stty -raw echo');
			print "\n";
	       	exit(0);
        }
                
        # printable char
        if (ord >= 32 && $_ ne $erase1)
        {
        	$path .= $_;
        	$len++;
	        print;
        }        
    }
   
    system('stty -raw echo');
    print "\n";
    return $path;
}

