# This script is copyright (c) 2006 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

# READ THIS FIRST:
# This file will attempt to enforce the most secure permissions possible on your WebMO installation.
# This will only work if WebMO is running under suexec or cgi-wrap!  Use diagnose.pl to see if 
# suexec is enabled before running this script.
# usage: secure.pl <path-to-globals.int>

my $globals = shift;

#parse globals.int
local *handle;
open(handle, "<$globals") || die "Cannot open $globals: $!";
while(<handle>)
{
	chomp;
	my ($variable, $value) = split(/=/, $_, 2);
	my $expression = "\$$variable=$value;";
	eval $expression;
}
close(handle);

chmod(0755, "$cgiBase/interfaces");
my $interfaceFiles = "$cgiBase/interfaces/*.int";
chmod(0644, $_) while (<${interfaceFiles}>);
$interfaceFiles = "$cgiBase/interfaces/*.int.disabled";
chmod(0644, $_) while (<${interfaceFiles}>);
my $tmplFiles = "$cgiBase/interfaces/*.tmpl";
chmod(0644, $_) while (<${tmplFiles}>);
chmod(0644, "$cgiBase/interfaces/fragments.txt");
chmod(0644, "$cgiBase/interfaces/pbs.conf");
chmod(0644, "$cgiBase/interfaces/authen.conf");

chmod(0755, "$cgiBase/servers");
chmod(0755, "$cgiBase/queues");

chmod(0755, $userBase);
chmod(0644, "$userBase/log");
chmod(0644, "$userBase/errors");
chmod(0644, "$userBase/queue");

chmod(0644, "$userBase/jobs.db");
chmod(0644, "$userBase/.jobs.index");
chmod(0644, "$userBase/groups.db");
chmod(0644, "$userBase/.groups.index");
chmod(0644, "$userBase/users.db");
chmod(0644, "$userBase/.users.index");

chmod(0755, "$userBase/admin");

chmod(0755, "$systemScratch/webmo");
