# This script is copyright (c) 2006 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

my $qchemBase = "/usr/local/qchem";
my $qchemVersion = "3.0";

if (!(-d $qchemBase))
{
	$qchemBase = "";
	
	&divider;
	print "SETUP Q-CHEM\n\n";
	print "The following section will attempt to set up WebMO for\n";
	print "use with the Q-Chem software package.\n\n";

	print "Have you previously installed Q-Chem [y/n]:";
	local $choice = "";
	while ($choice eq "")
	{
		local $trial_choice = "";
		$trial_choice = <STDIN>;
		chomp $trial_choice;
		
		if ($trial_choice =~ /^y/i)
		{
			$choice = "y";
		}
		elsif ($trial_choice =~ /^n/i)
		{
			$choice = "n";
		}
	}
	if ($choice eq "n")
	{
		print "Exiting Q-Chem specific setup.\n";
		exit(0);
	}
	
	while ($qchemBase eq "")
	{
		local $trial_directory = &complete("Enter Q-Chem directory: ");
		chomp $trial_directory;

		if ($trial_directory !~ /^\//) 
		{
			print "Your directory specification must start with a / character\n";
			print "as it must be an absolute directory.  You cannot use ~ to\n";
			print "indicate your home directory, nor . to use a relative\n";
			print "directory.\n";
		}	
		elsif (!(-d $trial_directory))
		{
			print "That directory does not exist.\n";
		}
		else
		{
			$qchemBase = $trial_directory;
		}
	}	
}
print "Setting up WebMO for use with Q-Chem...";

local(*handle);
system("mv $cgiBase/interfaces/qchem.int.disabled $cgiBase/interfaces/qchem.int");

open(handle, "<$cgiBase/interfaces/qchem.int");
my @contents = <handle>;
close(handle);

open(handle, ">$cgiBase/interfaces/qchem.int");
foreach (@contents)
{
	my ($token, $value) = split(/=/, $_, 2);
	chomp $value;
	$value = "\"$qchemBase\"" if ($token eq 'qchemBase');
	$value = "\"$qchemVersion\"" if ($token eq 'qchemVersion');
	print handle "$token=$value\n";
}
close(handle);

print "done\n";

sub divider {
	print ">", "=" x 58, "<", "\n";
	print "\n";
}

sub complete
{
	local $complete = "\004";
    local $kill     = "\003";	
    local $erase1 =   "\177";
    local $erase2 =   "\010";
    local @cmp_lst;        
    local ($prompt) = @_;        
    local $path = "";
    local $len = 0;
    
    local *dir;
    print($prompt, $path);

	system('stty raw -echo');
    while (($_ = getc(STDIN)) ne "\r")
    {
    	$path = substr($path, 0, $len);

		$path =~ /(.*)\/[^\/]*$/;
    	$current_path = $1."/";
	    opendir(dir,  $current_path =~ /^[\/.]/ ? $current_path : "./".$current_path);
	    @cmp_lst = readdir(dir);
	    closedir(dir);
			    
	    foreach (@cmp_lst)
	    {
	    	$_ = $current_path.$_;
	    }    	
    	
        # (TAB) attempt completion
        if ($_ eq "\t")
        {
        	@match = grep(/^$path/, @cmp_lst);
            $matches = @match;
            $l = length($test = shift(@match));
            unless ($#match < 0)
            {
            foreach $cmp (@match)
            	{
					until (substr($cmp, 0, $l) eq substr($test, 0, $l))
                	{
                    	$l--;
                    }
                }
                print("\a");
            }
            print($test = substr($test, $len, $l - $len));
            $len = length($path .= $test);
            
            if (-d $path && $matches == 1)
            {
				print "/";
            	$len = length($path .= "/");            	
            }
        }
    	
        # (^D) completion list
        if ($_ eq $complete)
        {
	    	print(join("\r\n", '', grep(/^$path/, @cmp_lst)), "\r\n");
    	    print($prompt, $path);
        };
    
        # (DEL) || (BS) erase
        if ($_ eq $erase1 || $_ eq $erase2)
        {
			if ($len)
        	{
		        print("\b \b");
		        $len--;
		    }
        }
        
        # (^C) kill
        if ($_ eq $kill)
        {
			system('stty -raw echo');
			print "\n";
	       	exit(0);
        }
                
        # printable char
        if (ord >= 32 && $_ ne $erase1)
        {
        	$path .= $_;
        	$len++;
	        print;
        }
    }
   
    system('stty -raw echo');
    print "\n";
    return $path;
}
