# This script is copyright (c) 2011 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

# attempt to set the library path around the location of THIS script
# so that we can use WebMO files
use FindBin;
use lib "$FindBin::Bin";
use lib "$FindBin::Bin/../cgi-bin";
use lib "$FindBin::Bin/../cgi-bin/lib";

my $globals = shift;

# read the path to globals.int on the command line if its there
$interactive = 1 if ($globals eq "");

# try to find globals.int ourself
$globals = "./interfaces/globals.int" if (-e "./interfaces/globals.int");

print "\n";
print "WELCOME TO WEBMO MIGRATE JOBS UTILITY\n\n";
print "This utility will migrate user jobs from the WebMO 'user'\n";
print "directory to user home directories, assuming that the 'User\n";
print "storage option has been enabled within WebMO\n\n";
&pause;

#ask the user to locate globals.int
if ($globals eq "") {
	&divider;
	print "Please locate the globals.int file.  This file is installed in the location\n";
	print "<webmo>/cgi-bin/interfaces/globals.int\n\n";
}

while ($globals eq "")
{
	my $trial_globals = &complete("Location: ");
	chomp $trial_globals;
	if (!(-f $trial_globals))
	{
		print "That file does not exist.\n";
	}
	else
	{
		$globals = $trial_globals;
	}
}

#parse globals.int
local *handle;
open(handle, "<$globals");
while(<handle>)
{
	chomp;
	my ($variable, $value) = split(/=/, $_, 2);
	my $expression = "\$$variable=$value;";
	eval $expression;
}
close(handle);

$require++;
require("globals.cgi");
require("join_group.cgi");
$require--;

print "Enter username to migrate ['all' for all users]: ";
my $username = <>;
chomp $username;

if (lc $username eq 'all')
{
	my @usernames = &get_usernames();
	foreach my $username (@usernames)
	{
		next if &is_administrator($username);
		&setup_user_storage($username);
	}
}
else
{
	&setup_user_storage($username);
}

########################################################################
#  Subroutines

sub divider {
	print ">", "=" x 58, "<", "\n";
	print "\n";
}

sub pause
{
print "Enter to continue";
local $temp = <STDIN>;
}

sub complete
{
	local $complete = "\004";
    local $kill     = "\003";	
    local $erase1 =   "\177";
    local $erase2 =   "\010";
    local @cmp_lst;        
    local ($prompt) = @_;        
    local $path = "";
    local $len = 0;
    
    local *dir;
    print($prompt, $path);

	system('stty raw -echo');    
    while (($_ = getc(STDIN)) ne "\r")
    {
    	$path = substr($path, 0, $len);

		$path =~ /(.*)\/[^\/]*$/;
    	$current_path = $1."/";
	    opendir(dir,  $current_path =~ /^[\/.]/ ? $current_path : "./".$current_path);
	    @cmp_lst = readdir(dir);
	    closedir(dir);
			    
	    foreach (@cmp_lst)
	    {
	    	$_ = $current_path.$_;
	    }    	
    	
        # (TAB) attempt completion
        if ($_ eq "\t")
        {
        	@match = grep(/^$path/, @cmp_lst);
            $matches = @match;
            $l = length($test = shift(@match));
            unless ($#match < 0)
            {
				foreach $cmp (@match)
            	{
					until (substr($cmp, 0, $l) eq substr($test, 0, $l))
                	{
                    	$l--;
                    }
                }
                print("\a");
            }
            print($test = substr($test, $len, $l - $len));
            $len = length($path .= $test);
            
            if (-d $path && $matches == 1)
            {
				print "/";
            	$len = length($path .= "/");            	
            }
        }
    	
        # (^D) completion list
        if ($_ eq $complete)
        {
	    	print(join("\r\n", '', grep(/^$path/, @cmp_lst)), "\r\n");
    	    print($prompt, $path);
        };
    
        # (DEL) || (BS) erase
        if ($_ eq $erase1 || $_ eq $erase2)
        {
			if ($len)
        	{
		        print("\b \b");
		        $len--;
		    }
        }
        
        # (^C) kill
        if ($_ eq $kill)
        {
			system('stty -raw echo');
			print "\n";
	       	exit(0);
        }
                
        # printable char
        if (ord >= 32 && $_ ne $erase1)
        {
        	$path .= $_;
        	$len++;
	        print;
        }        
    }
   
    system('stty -raw echo');
    print "\n";
    return $path;
}

