# This script is copyright (c) 2020 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

# attempt to set the library path around the location of THIS script
# so that we can use SimpleDB
use FindBin;
use lib "$FindBin::Bin";
use lib "$FindBin::Bin/../cgi-bin";

#USAGE: make_image.pl <globals.int>
my $globals = shift;

#parse globals.int
open(my $handle, "<$globals") || die "Cannot open $globals: $!";
while(<$handle>)
{
	chomp;
	my ($variable, $value) = split(/=/, $_, 2);
	my $expression = "\$$variable=$value;";
	eval $expression;
}
close($handle);

print "This will delete ALL users and jobs and clear ALL databases. Continue?\n";
my $confirm = <>;
chomp $confirm;

die "Exiting" unless (uc $confirm eq "Y");

#disable activation and wipe the license number
system("perl -pi -e 's/license=\".*\"/license=\"\"/' $globals");
system("touch disable_activation");

#set the CWD to the userBase
chdir($userBase);

die "Must be run from \$userDir" unless (-d "admin");

#enumerate all users via the directory
opendir( my $DIR, "." );
while ( my $entry = readdir $DIR ) {
    next unless -d './' . $entry;
    next if $entry eq '.' or $entry eq '..';
    next if ($entry eq 'admin' or $entry eq 'backup');
    my $user = $entry;
    print "Deleting user: $user\n";
    system("perl $FindBin::Bin/delete_user.pl $user"); 
}
closedir $DIR;

#clean up the databases
system("rm .*.index");
unlink("jobs.db"); system("touch jobs.db");
system("mv users.db users.db.old; head -1 users.db.old > users.db; rm users.db.old");
system("mv groups.db groups.db.old; head -1 groups.db.old > groups.db; rm groups.db.old");

#reset the admin password
system("perl $FindBin::Bin/reset_passwd.pl users.db");

exit(0);
