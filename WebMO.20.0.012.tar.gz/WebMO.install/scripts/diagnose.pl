# This script is copyright (c) 2006 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

use File::stat;
use File::Find;

my $interactive = 0;
my $globals = shift;


# read the path to globals.int on the command line if its there
$interactive = 1 if ($globals eq "");

# try to find globals.int ourself
$globals = "./interfaces/globals.int" if (-e "./interfaces/globals.int");


#if Windows, no need to diagnose!
my $os = $^O;
if ($os =~ /MSWin/)
{
	print "Diagnose detected Windows OS.  Diagnose\n";
	print "is typically not needed on Windows, and\n";
	print "is thus not implemented.\n\n";
	<>;
	exit(0);
}


if ($interactive)
{
	print "\n";
	print "WELCOME TO WEBMO DIAGNOSTIC UTILITY\n\n";
	print "This utility will attempt to validate the configuraton of your WebMO\n";
	print "installation and applicable Apache webserver settings. The diagnostic\n";
	print "script produces an HTML file of results (diagnose.html) that can be\n";
	print "viewed with a standard web browser or emailed to WebMO for diagnostic\n";
	print "purposes.\n";
	&pause;

	#ask the user to locate globals.int
	if ($globals eq "") {
		&divider;
		print "Please locate the globals.int file.  This file is installed in the location\n";
		print "<webmo>/cgi-bin/interfaces/globals.int\n\n";
	}

	while ($globals eq "")
	{
		my $trial_globals = &complete("Location: ");
		chomp $trial_globals;

		if (!(-f $trial_globals))
		{
			print "That file does not exist.\n";
		}
		else
		{
			$globals = $trial_globals;
		}
	}
}

#parse globals.int
local *handle;
open(handle, "<$globals");
while(<handle>)
{
	chomp;
	my ($variable, $value) = split(/=/, $_, 2);
	my $expression = "\$$variable=$value;";
	eval $expression;
}
close(handle);

open(handle, ">diagnose.html");

print handle <<End;
<HTML>
	<HEAD><TITLE>WebMO Diagnostic Output</TITLE></HEAD>
	<BODY>

<PRE>
<H1>WebMO Diagnostic Output</H1>
The following information can be used to diagnose WebMO configuration problems.
Any <FONT color="red"><B>failures</B></FONT> will be marked in red.

End

print handle "<H3>System Information</H3>";
find_system_file("uname", \@results);
print handle `$results[0] -a`;
print handle "\n";

# Check home directory
if ($ENV{'HOME'} ne "")
{
	print handle "<H3>Checking Home Directory</H3>";
	my $stat_info = stat($ENV{'HOME'});
	my $leng = length($ENV{'HOME'});

	print handle "Checking home directory:";
	if (($stat_info->mode & 00001) != 1)
	{
		print handle "&nbsp;" x (59 - $leng);
		print handle "<FONT COLOR=\"red\"><B>Failed</B></FONT>\n";
		printf handle "<B>Home directory must be world-executable if WebMO is installed there</B>\n"
	}
	else
	{
		print handle "&nbsp;" x (59 - $leng);
		print handle "<FONT COLOR=\"green\"><B>Passed</B></FONT>\n";
	}
	print handle "\n";
}

# Check permissions
print handle "<H3>Checking CGI Directory</H3>";
&check_file_permissions("$cgiBase", 0755);
&check_file_permissions("$cgiBase/login.cgi", 0755);
&check_file_permissions("$cgiBase/interfaces", 0777);
&check_file_permissions("$cgiBase/interfaces/globals.int", 0777);
print handle "\n";

print handle "<H3>Checking User Directory</H3>";
&check_file_permissions("$userBase", 0777);
&check_file_permissions("$userBase/jobs.db", 0777);
&check_file_permissions("$userBase/users.db", 0777);
&check_file_permissions("$userBase/queue", 0777);
&check_file_permissions("$userBase/errors", 0777);
print handle "\n";
		
#print handle "<H3>Checking Scratch Directory</H3>";
#&check_file_permissions("$systemScratch/webmo-$uniqueId", 0777);
#print handle "\n";

if (-d "/etc/selinux")
{
print handle "<H3>Checking SELinux configuration</H3>";
print  handle ($text = "Checking for SELinux disabled:");
$len = length($text);
if (`grep -c -i "SELINUX=enabled" /etc/selinux/config` == 0 &&
	`grep -c -i "SELINUX=enforcing" /etc/selinux/config` == 0 &&
	`grep -c -i "SELINUX=targeted" /etc/selinux/config` == 0)
{
	print handle "&nbsp;" x (70 - $len);
	print handle "<FONT COLOR=\"green\"><B>Passed</B></FONT>\n";
}
else
{
	print handle "&nbsp;" x (70 - $len);
	print handle "<FONT COLOR=\"red\"><B>Failed</B></FONT>\n";
	print handle "<B>SELinux may cause problems with CGI scripts; consider disabling by editing '/etc/selinux/config'</B>";
}
print handle "\n";
}
	
# Apache configuration
check_apache_config();
	
# Output globals.int
print handle "<H3>WebMO Configuration File</H3>";

open(handle2, "$globals");
print handle <handle2>;
close(handle2);
print handle "\n";

# Output contents of error log
print handle "<H3>WebMO Error Log</H3>";
print handle `$catPath $userBase/errors`;

# Output sample 'ps' information
print handle "<H3>Sample Process Information</H3>";
print handle `$psPath $psOptions`;

print handle <<End;

For support information, visit our <A HREF="http://www.webmo.net">website</A> or email <A HREF="mailto:support\@webmo.net">support\@webmo.net</A>.
</PRE>
	</BODY>
</HTML>
End

close(handle);

########################################################################
#  Subroutines

sub divider {
	print ">", "=" x 58, "<", "\n";
	print "\n";
}

sub pause
{
print "Enter to continue";
local $temp = <STDIN>;
}

sub complete
{
	local $complete = "\004";
    local $kill     = "\003";	
    local $erase1 =   "\177";
    local $erase2 =   "\010";
    local @cmp_lst;        
    local ($prompt) = @_;        
    local $path = "";
    local $len = 0;
    
    local *dir;
    print($prompt, $path);

	system('stty raw -echo');    
    while (($_ = getc(STDIN)) ne "\r")
    {
    	$path = substr($path, 0, $len);

		$path =~ /(.*)\/[^\/]*$/;
    	$current_path = $1."/";
	    opendir(dir,  $current_path =~ /^[\/.]/ ? $current_path : "./".$current_path);
	    @cmp_lst = readdir(dir);
	    closedir(dir);
			    
	    foreach (@cmp_lst)
	    {
	    	$_ = $current_path.$_;
	    }    	
    	
        # (TAB) attempt completion
        if ($_ eq "\t")
        {
        	@match = grep(/^$path/, @cmp_lst);
            $matches = @match;
            $l = length($test = shift(@match));
            unless ($#match < 0)
            {
				foreach $cmp (@match)
            	{
					until (substr($cmp, 0, $l) eq substr($test, 0, $l))
                	{
                    	$l--;
                    }
                }
                print("\a");
            }
            print($test = substr($test, $len, $l - $len));
            $len = length($path .= $test);
            
            if (-d $path && $matches == 1)
            {
				print "/";
            	$len = length($path .= "/");            	
            }
        }
    	
        # (^D) completion list
        if ($_ eq $complete)
        {
	    	print(join("\r\n", '', grep(/^$path/, @cmp_lst)), "\r\n");
    	    print($prompt, $path);
        };
    
        # (DEL) || (BS) erase
        if ($_ eq $erase1 || $_ eq $erase2)
        {
			if ($len)
        	{
		        print("\b \b");
		        $len--;
		    }
        }
        
        # (^C) kill
        if ($_ eq $kill)
        {
			system('stty -raw echo');
			print "\n";
	       	exit(0);
        }
                
        # printable char
        if (ord >= 32 && $_ ne $erase1)
        {
        	$path .= $_;
        	$len++;
	        print;
        }        
    }
   
    system('stty -raw echo');
    print "\n";
    return $path;
}

sub find_system_file
{
	local($systemFile, *list) = @_;	
	local $output = `whereis $systemFile`;

	@list = ();

	$output =~ tr/\n/ /;
	if ($output =~ /$systemFile: (.*)/)
	{
		$output = $1;
	}
	
	local @options = split(/\s+/, $output);
	foreach (@options)
	{
		if (/$systemFile$/)
		{
			push @list, $_;
		}
	}
}

sub check_file_permissions()
{
	my ($filename, $permissions) = @_;
	my $len = length($filename);
	my $item = (-d $filename ? "directory" : "file");

	print handle "Checking $filename:";
	
	if (!(-e $filename))
	{
		print handle "&nbsp;" x (60 - $len);
		print handle "<FONT COLOR=\"red\"><B>Failed</B></FONT>\n";
		print handle "<B>This file/directory does not exist</B>\n";
		return;
	}
	my $stat_info = stat($filename);
#	if (($stat_info->mode & 07777) != $permissions)
#	{
#		print handle "&nbsp;" x (60 - $len);
#		print handle "<FONT COLOR=\"red\"><B>Failed</B></FONT>";
#		printf handle "<B>Permissions of this $item should %04o</B>\n", $permissions
#	}
#	else
#	{
		print handle "&nbsp;" x (60 - $len);
		print handle "<FONT COLOR=\"green\"><B>Passed</B></FONT>";
		printf handle "( %04o, %s )\n", $stat_info->mode & 07777, getpwuid($stat_info->uid);
#	}
}

sub check_apache_config()
{
	local $httpd = "";
	my @contents;
	my @results;
	my $text, $len;

	# check for httpd.conf in various location (order is significant)
	find(\&Wanted, "/etc/apache2") unless ($httpd || !(-d "/etc/apache2"));
	find(\&Wanted, "/etc") unless ($httpd);
	find(\&Wanted, "/usr/local/etc") unless ($httpd || !(-d "/usr/local/etc"));
	
	# If httpd.conf is not under either of the above locations, 
	# you can uncomment the following line
	# $httpd = "enter the location of httpd.conf on your system here"
	return if ($httpd eq "");
	
	print handle "<H3>Checking Apache Configuration</H3>";
	
	open(handle2, "<$httpd");
	@contents = <handle2>;
	close(handle2);

	my $httpd_local = "$httpd.local";
	if (-e $httpd_local)
	{
		open(handle2, "<$httpd_local");
		push(@contents, <handle2>);
		close(handle2);
	}
	
	# check for AddHandler for cgi scripts	
	print  handle ($text = "Checking for AddHandler cgi-scripts enabled: ");
	$len = length($text);
	@results = grep(/AddHandler cgi\-script/, @contents);
	if ($results[0] =~ /^#/)
	{
		print handle "&nbsp;" x (70 - $len);
		print handle "<FONT COLOR=\"red\"><B>Disabled</B></FONT>\n";
		print handle "<B>Optionally uncomment the line 'AddHandle cgi-scripts .cgi'</B>";
		print handle "(<A HREF='http://www.webmo.net/support/fedoracore4.html#apache_conf'>Apache configuration instructions</A>)\n";
	}
	else
	{
		print handle "&nbsp;" x (70 - $len);
		print handle "<FONT COLOR=\"green\"><B>Enabled</B></FONT>\n";
	}
	
	# check for user directories
	print  handle ($text = "Checking for UserDir enabled: ");
	$len = length($text);
	@results = grep(/UserDir /, @contents);
	if ($results[0] =~ /^#/)
	{
		print handle "&nbsp;" x (70 - $len);
		print handle "<FONT COLOR=\"red\"><B>Failed</B></FONT>\n";
		print handle "<B>Uncomment the line 'UserDir public_html'</B>";
		print handle "(<A HREF='http://www.webmo.net/support/fedoracore4.html#apache_conf'>Apache configuration instructions</A>)\n";
	}
	else
	{
		print handle "&nbsp;" x (70 - $len);
		print handle "<FONT COLOR=\"green\"><B>Passed</B></FONT>\n";
	}
	
	# check for suexec
	print  handle ($text = "Checking for suExec enabled: ");
	$len = length($text);
	find_system_file("suexec", \@results);
	find_system_file("suexec2", \@results) if (@results == 0);
	if (!(-u $results[0] || (-e "/usr/sbin/getcap" && `getcap $results[0]`)))
	{
		print handle "&nbsp;" x (70 - $len);
		print handle "<FONT COLOR=\"red\"><B>Disabled</B></FONT>\n";
		print handle "<B>No changes are necessary</B>\n";
	}
	else
	{
		print handle "&nbsp;" x (70 - $len);
		print handle "<FONT COLOR=\"green\"><B>Enabled</B></FONT>\n";
	}
			
	# web user	
	@results = grep(/^User /, @contents);
	foreach(@results)
	{
		/User\s+(\S+)/;
		print handle "Apache is running as user $1\n";
	}	
	
	# find the document root
	@results = grep(/^DocumentRoot/, @contents);
	foreach(@results)
	{
		/DocumentRoot\s+\"(\S+)\"/;
		print handle "Document root directory is $1\n";
	}
	
	# find the script alias directory(s)
	@results = grep(/^ScriptAlias/, @contents);
	foreach(@results)
	{
		/ScriptAlias\s+(\S+)\s+\"(\S+)\"/;
		print handle "Script alias directory is $2 (URL: $1)\n";
	}
	
	#check for exec CGI in directories
	my $i, $in_dir = 0, $dir_name;
	for ($i = 0; $i < @contents; $i++)
	{
		$_ = $contents[$i];
		
		if (/<Directory (.*)>/i)
		{
			$in_dir = 1;
			$dir_name = $1;
		}
		$in_dir = 0 if (/<\/Directory>/i);
		
		if ($in_dir && /[^#].*Options .*ExecCGI/i)
		{
			print handle "ExecCGI enabled for directory $dir_name\n";
		}
		if ($in_dir && /[^#].*SetHandler .*cgi\-script/i)
		{
			print handle "SetHandler cgi-script enabled for directory $dir_name\n";
		}
	}
	
	#check for PrivateTmp
	my $serviceFile;
	foreach my $file ("/usr/lib/systemd/system/httpd.service", "/etc/systemd/system/httpd.service") {
		if (-e $file) {
			if (`grep -c -i "PrivateTmp=true" $file` != 0) {
				print  handle ($text = "Checking for use of PrivateTmp in httpd.service: ");
				$len = length($text);		
				print handle "&nbsp;" x (70 - $len);
				print handle "<FONT COLOR=\"red\"><B>Enabled</B></FONT>\n";
				print handle "<B>PrivateTmp must be disabled if using PBS/Troque</B>\n";
			}		
		}
	}
			
	print handle "\n";
}

sub Wanted()
{
	$File::Find::prune = 1 if (-d $_ && !(-r $_));
	$httpd = $File::Find::name if (/^httpd.conf$/);
}
