# This script is copyright (c) 2007 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

# attempt to set the library path around the location of THIS script
# so that we can use SimpleDB
use FindBin;
use lib "$FindBin::Bin";
use lib "$FindBin::Bin/../cgi-bin";

use SimpleDB;

my $db_file = shift;
die "Usage: reset_password.pl users.db" unless (-e $db_file);

my @db_fields = ('username', 'group', 'isAdministrator', 'enabled', 'password', 'sessionId', 'profile', 'newline');
my $db_rec_format = 'A32 A32 c c A13 A13 A2048 a1';
my $db_ref = new SimpleDB($db_file, "/dev/null", \@db_fields, $db_rec_format, 'username');

#my $record = $db_ref->find_record_by_key("admin");
#we don't have access to the index
my $record = 1;

my %userInfo;
$db_ref->fetch_record($record, \%userInfo);
$userInfo{'password'} = "";
$db_ref->update_record($record, \%userInfo);

print "WebMO 'admin' password reset to <blank>.\n";