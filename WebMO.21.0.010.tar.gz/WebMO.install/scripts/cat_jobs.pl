# This script is copyright (c) 2006 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

die "USAGE: cat_jobs.pl jobs.db" if (@ARGV != 1 && @ARGV != 2);
my $verbose = $ARGV[1] eq 'verbose' ? 1 : 0;

my ($newfile) = @ARGV;
my $rec_str = "L A32 A64 A32 A10 L A9 c A32 L f c c a1";
my $rec_len = length(pack($rec_str));

open(newjobs, "<$newfile");
binmode(newjobs);

while(read(newjobs, $_, $rec_len) > 0)
{
	my ($jobNumber, $jobUser, $jobName, $jobDescription, $engine, $jobDate,
	    $jobStatus, $failureCode, $server, $pid, $cpu_time, $checkpointFile, $folder) = unpack($rec_str, $_);
	$engine = ucfirst $engine;

	if ($verbose)
	{
		print "Job number: $jobNumber\n";
		print "User: $jobUser\n";
		print "Description: $jobDescription\n";
		print "Computational engine: $engine\n";
		print "Date: ", &asctime($jobDate), "\n";
		print "Status: $jobStatus\n";
		print "Failure code: $failureCode\n" if ($jobStatus eq 'failed');
		print "Server: $server\n";
		print "PID: $pid\n";
		print "CPU time: $cpu_time\n";
		print "<Checkpoint file exists>\n" if ($checkpointFile);
		print "Folder index: $folder\n";
		print "\n";
	}
	else
	{
		print "$jobNumber:$jobUser:$jobName:$jobDescription - $engine:$jobDate:$jobStatus:$server,$pid:$cpu_time:$checkpointFile:$folder\n";
	}
}

close(newjobs);


sub asctime
{
        my($currentTime) = @_;
        my($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($currentTime);
        $mon++;
        $year+=1900;
        $min = "0$min" if ($min < 10);
        return "$mon/$mday/$year $hour:$min";
}
