# This script is copyright (c) 2006 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

die "USAGE: cat_groups.pl groups.db <verbose>" if (@ARGV != 1 && @ARGV != 2);
my $verbose = $ARGV[1] eq 'verbose' ? 1 : 0;

my ($newfile) = @ARGV;
my $rec_str = 'A32 A2048 a1';
my $rec_len = length(pack($rec_str));

open(newjobs, "<$newfile");
binmode(newjobs);

while(read(newjobs, $_, $rec_len) > 0)
{
	my ($group, $profile, $newline) = unpack($rec_str, $_);

	if ($verbose)
	{
		print "Group: $group\n";
		print "Contents of group profile:\n";
		foreach (split(/\0/,$profile))
		{
			print "$_\n";
		}
		print "\n";
	}
	else
	{
		print "$group\n";
	}
}

close(newjobs);
