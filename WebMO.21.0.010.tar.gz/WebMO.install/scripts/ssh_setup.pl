`reg delete HKEY_USERS\\.Default\\Software\\SimonTatham /f`;
`reg copy HKEY_CURRENT_USER\\Software\\SimonTatham HKEY_USERS\\.Default\\Software\\SimonTatham /s`;
print "SSH setup complete. Hit <enter> to exit.";
$_ = <>;
