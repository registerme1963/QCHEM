# This script is copyright (c) 2006 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

die "USAGE: convert_users.pl users users.db user_dir" if (@ARGV != 3);

my ($oldfile, $newfile, $userBase) = @ARGV;
my $rec_str = "A32 A32 c c A13 A13 A2048 a1";

open(oldusers, "<$oldfile");
open(newusers, ">$newfile");
binmode(newusers);

while(<oldusers>)
{
	chomp;
	my($username, $password) = split(/:/, $_);
	my ($group, $session, $enabled, $isAdmin) = ('webmo', '', 1, 0);
	my $profile;

	$isAdmin = 1 if ($username eq 'admin');
	
	open(fh, "$userBase/$username/profile");
	while(<fh>)
	{
		chomp;
		$profile .= $_.chr(0) unless (/^username=/);
	}
	$profile .= 'enabledInterfaces=all'.chr(0);
	$profile .= 'enabledServers=all'.chr(0);
	$profile .= 'enabledQueues=all'.chr(0);
	close(fh);
	chop $profile;

	print newusers pack($rec_str, $username, $group, $isAdmin, $enabled, $password, $session, $profile, "\n");
}

close(oldusers);
close(newusers);
