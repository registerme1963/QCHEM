var bmenuItems =
[
  ["$Add server", "content1"],
  ["Edit servers",  "content2"],
];

apy_tabsInit();