package FailureCodes;

# a list of failure codes
$Uninitialized = 0;
$UnknownFailure = 32;
$KilledByDaemon = 33;
$KilledByUser = 34;
$KilledByAdmin = 35;
$KilledByDaemonZombie = 36;

$WrongMultiplicity = 1;
$OptFailedTooManyIterations = 2;
$BadGeometryAtomsTooClose = 3;
$BadGeometryColinearAtoms = 4;
$SyntaxErrorInInput = 5;
$TooManyAtoms = 6;
$InsufficientMemory = 7;
$BrokenSymmetry = 8;
$IncompatiblePseudopotentials = 9;

my %FailureText = 
	(
		$Uninitialized					=> 'Unknown or unspecified job failure',
		$UnknownFailure 				=> 'Unknown or unspecified job failure',
		$KilledByDaemon 				=> 'Job killed by daemon; job exceeded allotted CPU time',
		$KilledByUser	 				=> 'Job killed by user',
		$KilledByAdmin	 				=> 'Job killed by an administrator',
		$KilledByDaemonZombie			=> 'Job killed by daemon; job could no longer be found in batch queue',
		
		$WrongMultiplicity 				=> 'Chosen multiplicity is incompatible with the number of electrons',
		$OptFailedTooManyIterations 	=> 'Optimization not converged (too many iterations); increase max. number of iterations',
		$BadGeometryAtomsTooClose		=> 'Bad geometry (at least one pair of atoms is unreasonably close); check geometry',
		$BadGeometryColinearAtoms		=> 'Bad geometry (3 or more atoms are colinear); use Cartesian coordinates',
		$SyntaxErrorInInput				=> 'Syntax error in input file',
		$TooManyAtoms					=> 'Too many atoms in calculation',
		$InsufficientMemory				=> 'Calculation requires more memory than has been allocated or is available',
		$BrokenSymmetry					=> 'Symmetry was broken during the optimization process',
		$IncompatiblePseudopotentials	=> 'Mutually incompatible pseudopotentials were specified'
	);

sub GetText
{
	my ($failure_code) = @_;
	return $FailureText{$failure_code};
}

1;