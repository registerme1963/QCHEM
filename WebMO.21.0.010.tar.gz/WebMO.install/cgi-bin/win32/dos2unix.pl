# This script is copyright (c) 2007 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

my @files = <{$ARGV[0]}>;
foreach my $file (@files)
{
	my $handle;
	open($handle, "<$file");
	my @contents = <$handle>;
	close($handle);
		
	open($handle, ">$file");
	binmode($handle);
	foreach (@contents)
	{
		chomp;
		print $handle "$_\n";
	}
	close($handle);
}

