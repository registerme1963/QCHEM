# This script is copyright (c) 2006 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

use lib 'cgi-bin';
use lib 'cgi-bin/lib';

local $version;
local $oem;
local $oem_setup_script;
local $pro = 0;
local $enterprise = 0;

local $license = "";
local $userBase="";
local $htmlBase="";
local $cgiBase="";
local $webserver="";
local $host="";
local $url_htmlBase="";
local $url_cgiBase="";
local $systemScratch="/tmp";
local $whereisPath="";
local $perlPath;
local $psRegExp="";
local $owner="Computational Chemistry on the WWW";
local $uniqueId=$$;

umask 0;

#if necessary on Windows, bootstrap ourself to elevate privileges
my $os = $^O;
if ($os =~ /MSWin/ && !($ARGV[0] eq 'win32_elevated'))
{
	my $ver_string = `ver`;
	my ($ver) = $ver_string =~ /Version (\d+\.\d+)/;
	#one Vista and higher, elevate privileges to avoid UAC issues
	if ($ver >= 6.0)
	{
		system("scripts\\elevate perl setup.pl win32_elevated");
		exit(0);
	}
}

#read version
open(temp, "<version");
$version = <temp>;
chomp $version;
close(temp);
$oem = $ENV{'WEBMO_OEM'} eq "" ? "webmo" : $ENV{'WEBMO_OEM'};

#Determine if this is a pro version
#Go ahead and tinker, this only changes what the installer displays, not what
#version you actually get :-)
if ($version =~ /p$/) { $pro = 1; }
if ($version =~ /e$/) { $enterprise = 1; }

#Check for existance of setup.conf for automated setup
local $unattended_setup = 0;
if (-e "setup.conf")
{
	$unattended_setup = 1;
	local *handle;
	open(handle, "<setup.conf");
	while(<handle>)
	{
		chomp;
		local ($variable, $value) = split(/=/, $_, 2);	
		eval("\$$variable=$value");
	}
	mkdir($htmlBase, 0755);
	mkdir($cgiBase, 0755);
	mkdir($userBase, 0755);
}
	
print "\n";
if ($enterprise) { print "WELCOME TO WEBMO ENTERPRISE VERSION $version SETUP\n\n"; }
elsif ($pro) { print "WELCOME TO WEBMO PRO VERSION $version SETUP\n\n"; }
else { print "WELCOME TO WEBMO BASIC VERSION $version SETUP\n\n"; }
print "In this portion of setup, you will be asked a few simple\n";
print "questions about file locations.  The WebMO files will then\n";
print "be copied onto this server.  After this is done you will log\n";
print "into WebMO to finish configuration.\n";
&pause;

#if necessary, call the windows-specific installation script
if ($os =~ /MSWin/)
{
	do(".\\scripts\\setup_win32.pl");
	print $@ if $@;
	exit(0);
}

#locate whereis for use in installation
local @instances;

if ($whereisPath eq "")
{
	&find_system_file("whereis", *instances);
	&find_system_file("which", *instances) if (@instances == 0);
	if (@instances > 0)
	{
		$whereisPath = $instances[0];
	}
	else
	{
		print "The utility 'whereis' could not be located because it is not in your\n";
		print "current path. To continue the installation, edit open setup.pl in your\n";
		print "text editor and change the following line near the beginning of the script:\n\n";
		print "'local \$perlPath = \"\";' to read 'local \$perlPath = \"/usr/bsd/whereis\";'\n";
		print "substituting /usr/bsd/whereis for the path to 'whereis' on your system.\n";
		exit(0);
	}
}

#get a username
my $username = `whoami`; chomp $username;
my $homedir = $ENV{'HOME'} ne "" ? $ENV{'HOME'} : `echo ~`; chomp $homedir;
if ($username eq "root")
{
	print <<END;
	
You are installing WebMO as the user 'root'.  It is strongly suggested that
you do not install WebMO as 'root', but rather do one of the following:
  1) Create a new 'webmo'account; log into this account, and install WebMO
     into the 'webmo' home directory
  2) Log into an existing user acconut, and install WebMO into the home 
     directory
  3) Continue installation as 'root', but install WebMO into your system
     wide html/cgi-bin directory (do not install into a user home directory
     as 'root', as the cgi scripts may not run correctly)
     
END
	print "Do you wish to continue with setup?";
	my $choice = <STDIN>;
	chomp $choice;
	exit (0) unless ($choice =~ /^y/i);
}

#get license information
&divider;
if (!$pro && !$enterprise)
{
	print "ENTER LICENSE INFORMATION\n\n";
	print "It is time to enter your WebMO license information.\n";
	print "Please enter your license information exactly as it was\n";
	print "received by you.  If you do not yet have a WebMO license\n";
	print "number, you can obtain one for free at www.webmo.net, or\n";
	print "this script can automatically obtain one for you now.\n\n";
}
else
{
	print "ENTER LICENSE INFORMATION\n\n";
	print "It is time to enter your WebMO license information.\n";
	print "Please enter your license information exactly as it was\n";
	print "received by you.\n\n";
}
if (!$unattended_setup && !$pro && !$enterprise)
{
	print "Have you previously obtained a WebMO license number [y/n]:";
	local $choice = "";
	while ($choice eq "")
	{
		local $trial_choice = "";
		$trial_choice = <STDIN>;
		chomp $trial_choice;
		
		if ($trial_choice =~ /^y/i)
		{
			$choice = "y";
		}
		elsif ($trial_choice =~ /^n/i)
		{
			$choice = "n";
		}
	}
	if ($choice eq "n")
	{
		print "Please enter the following information to obtain a license.\n";
		print "A license number will be email to the address provided below.\n";
		print "First name: ";
		my $first = <STDIN>;
		chomp $first;
		$first = escape($first);
		print "Last name: ";
		my $last = <STDIN>;
		chomp $last;
		$last = escape($last);
		print "Affiliation: ";
		my $affiliation = <STDIN>;
		chomp $affiliation;
		$affiliation = escape($affiliation);
		print "Email address: ";
		my $email = <STDIN>;
		chomp $email;
		$email = escape($email);
		my $reference = "$oem - installation";
		$reference = escape($reference);
		
		my $url = "https://www.webmo.net/cgi-bin/get/license.cgi";
		my $data ="first=$first&last=$last&affiliation=$affiliation&email=$email&reference=$reference&nocaptcha=true";

		eval("require IO::Socket::SSL");

		unless ($@) {
		
			my $HTTP = IO::Socket::SSL->new(
				PeerHost => "www.webmo.net",
				PeerPort => "https",
				SSL_verify_mode => 0, #SSL_VERIFY_NONE
			) or die "Could not connect to www.webmo.net: $!,$SSL_ERROR";
		
			# send and receive over SSL connection
			print $HTTP "GET $url?$data HTTP/1.1\r\n";
			print $HTTP "Host: www.webmo.net\r\n\r\n";
			close($HTTP);
		} else {
		
			#try to use wget
			system("curl -ks \"$url?$data\" > /dev/null ");
			
		}
		
		print "\nA license number has been emailed to the address that was specified.\n\n";
	}
}

my $attempts = 0;
while ($license eq "")
{
	print "License number: ";
	local $trial_license = <STDIN>;
	chomp $trial_license;

	if ($trial_license !~ /\d\d\d\d-\d\d\d\d-\d\d\d\d/)
	{
		print "The license must be in the form xxxx-xxxx-xxxx\n";
	}
	else
	{
		# This operation is check-summing your license information to help you catch
		# typographical errors.  Sure, you could easily circumvent it, but why would
		# you want to do that, unless you didn't have a valid license number!?!
		
		local ($first, $second, $third) = split(/-/, $trial_license);
				
		local @checksum = ( (($first*3+7) | ($second*5+13)) % 10, (($first*7+17) & ($second*11+19)) % 10, (($first*13+23) ^ ($second*17+29)) % 10, (($first*19+31) & ($second*23+33) ^ $first) % 10);
		
		$third =~ /(\d)(\d)(\d)(\d)/;
		if ($1 != $checksum[0] || $2 != $checksum[1] || $3 != $checksum[2] || $4 != $checksum[3])
		{
			print "The license number you entered was invalid.\n";
			die "Too many attempts" if ($attempts++ > 10);
		}
		else
		{
			$license = $trial_license;
		}
	}
}

#locate perl
&divider;
print "SET UP THE PATH TO PERL\n\n";
print "It is time to determine where the Perl interpreters are\n";
print "on your system.  We recommend selecting Perl 5 if\n";
print "it is available.\n\n";

print "The following Perl installations were detected on your server.\n";
print "You may choose to use one of these or you may specify another\n";
print "Perl installation that does not appear on the list.\n";
print "\n";

if ($perlPath eq "")
{
	&find_system_file("perl", *instances);
	local $counter = 0;
	foreach (@instances) {
		$counter++;
		print "$counter)  $_\n";
	}
	$counter++;
	print "$counter)  [Select a different Perl]\n\n";
	print "Please choose which Perl to use by entering a number from ";
	print "1 to $counter.\n\n";
	print "Your choice [1-$counter]: ";

	local $choice = <STDIN>;
	if ($choice < 1 || $choice > $counter)
	{
		print "Invalid choice.  Exiting script.\n";
		exit(0);
	}
	elsif($choice == $counter)
	{
		do 
		{
			$perlPath = &complete("Enter path to perl: ");
			chomp $perlPath;
		
			if (!(-e $perlPath))
			{
				print "Specified file does not exist\n";
			}
		}
		while (!(-e $perlPath));
	}
	else
	{
		$perlPath = $instances[$choice-1];
	}
}

#check for mod CGI
eval("use CGI");
die "You must install CGI.pm from your OS installation disk or CPAN.org before installing WebMO.\nFor example, rpm -ivh perl-CGI.\n" if ($@);

local $temp_host = $ENV{'HOST'};
if ($temp_host eq "")
{
	$temp_host = $ENV{'HOSTNAME'};
	if ($temp_host eq "")
	{
		$temp_host = `hostname`;
		chomp $temp_host;
	}
}
# translate 'short' hostnames into fully qualified hostnames
($temp_host) = gethostbyname($temp_host);

#locate local host
&divider;
print "SET UP WEBSERVER NAME\n\n";
print "The script has determined that the webserver name of this computer\n";
print "to be:\n\n";
print "   $temp_host\n\n";
print "IMPORTANT: This must represent the correct FULLY QUALIFIED webserver name\n";
print "(computer.domain.edu) for this computer.\n\n";
print "Is this webserver name fully qualified and correct [y/n]:";

local $choice = "y";
$choice = <STDIN> unless $unattended_setup;
chomp $choice;
		
if ($choice =~ /^y/i)
{
	$webserver = $host = $temp_host;
}
elsif ($choice =~ /^n/i)
{
	print "Webserver name: ";
	$webserver = $host = <STDIN>;
	chomp $webserver;
	chomp $host;
}		

#set up html directory
my $example;
foreach ("$homedir/public_html", "$homedir/Sites")
{
	$example = "$_/webmo" if (-d $_);
}
if ($example eq '')
{
	if ($username eq "root")
	{
		$example = "/var/www/html/webmo";
	}
	else
	{
		$example = "/home/$username/public_html/webmo";
	}
}
&divider;
print "SET UP HTML DIRECTORY\n\n";
print "The script will now create a directory into which the WebMO HTML\n";
print "files will be copied.  The directory should meet the following\n";
print "requirements:\n";
print "  - Directory is in the server's webspace\n";
print "  - The directory is NOT in a cgi-bin directory\n";
print "  - You need to have permission to write to this directory\n";
print "  - The parent of the specified directory must already exist\n\n";
print "Example:  $example\n\n";

while ($htmlBase eq "")
{
	local $trial_directory = &complete("Directory: ");
	chomp $trial_directory;

	if ($trial_directory !~ /^\//) 
	{
		print "Your directory specification must start with a / character\n";
		print "as it must be an absolute directory.  You cannot use ~ to\n";
		print "indicate your home directory, nor . to use a relative\n";
		print "directory.\n";
	}	
	elsif (!(-d $trial_directory))
	{
		print "That directory does not exist.\n";
		print "Create directory [y/n]:";
		
		local $choice = "";
		local $trial_choice = "";
		$trial_choice = <STDIN>;
		chomp $trial_choice;
		
		if ($trial_choice =~ /^y/i)
		{
			$choice = "y";
		}
		elsif ($trial_choice =~ /^n/i)
		{
			$choice = "n";
		}
		
		if ($choice eq "y")
		{
			if (!mkdir($trial_directory, 0755))
			{
				print "Unable to create directory: $!\n";
			}
			else
			{
				$htmlBase = $trial_directory;
			}
		}
	}
	elsif (!(-w $trial_directory))
	{
		print "You don't have permission to write to that directory\n";
	}
	else
	{
		$_ = $trial_directory;
		if (/\/$/)
		{
			chop;			
		}
		$htmlBase = $_;
	}
}

if ($username eq 'root')
{
	$example = "/webmo";
}
else
{
	$example = "/~$username/webmo";
}
print "\n";
print "Please enter the URL corresponding to the specified directory.\n";
print "Example:  $example\n\n";

while ($url_htmlBase eq "")
{
	print "URL: ";
	local $trial_url = <STDIN>;
	chomp $trial_url;

	if ($trial_url !~ /^\//) 
	{
		print "Your url specification must start with a / character\n";
		print "as it must be an absolute path.\n";
	} 
	else 
	{
		$_ = $trial_url;
		if (/\/$/)
		{
			chop;
		}
		$url_htmlBase = $_;
	}
}

#set up CGI directory
$example = "";
foreach ("$homedir/public_html", "$homedir/Sites")
{
	$example = "$_/cgi-bin/webmo" if (-d $_);
}
if ($example eq '')
{
	if ($username eq "root")
	{
		$example = "/var/www/cgi-bin/webmo";
	}
	else
	{
		$example = "/home/$username/public_html/cgi-bin/webmo";
	}
}
&divider;
print "SET UP CGI DIRECTORY\n\n";
print "The script will now create a directory into which the WebMO cgi\n";
print "scripts will be copied.  The directory should meet the following\n";
print "requirements:\n";
print "  - Directory is in the server's webspace\n";
print "  - Execution of CGI scripts is permitted in directory\n";
print "  - You need to have permission to write to this directory\n";
print "  - The parent of the specified directory must already exist\n\n";
print "Example:  $example\n\n";

while ($cgiBase eq "")
{
	local $trial_directory = &complete("Directory: ");
	chomp $trial_directory;

	if ($trial_directory !~ /^\//) 
	{
		print "Your directory specification must start with a / character\n";
		print "as it must be an absolute directory.  You cannot use ~ to\n";
		print "indicate your home directory, nor . to use a relative\n";
		print "directory.\n";
	}	
	elsif (!(-d $trial_directory))
	{
		print "That directory does not exist.\n";
		print "Create directory [y/n]:";
		
		local $choice = "";
		local $trial_choice = "";
		$trial_choice = <STDIN>;
		chomp $trial_choice;
		
		if ($trial_choice =~ /^y/i)
		{
			$choice = "y";
		}
		elsif ($trial_choice =~ /^n/i)
		{
			$choice = "n";
		}
		
		if ($choice eq "y")
		{
			if (!mkdir($trial_directory, 0755))
			{
				print "Unable to create directory: $!\n";
			}
			else
			{
				$cgiBase = $trial_directory;
			}
		}
	}
	elsif (!(-w $trial_directory))
	{
		print "You don't have permission to write to that directory\n";
	}
	else
	{
		$_ = $trial_directory;
		if (/\/$/)
		{
			chop;			
		}
		$cgiBase = $_;
	}
}

if ($username eq 'root')
{
	$example = "/cgi-bin/webmo";
}
else
{
	$example = "/~$username/cgi-bin/webmo";
}
print "\n";
print "Please enter the URL corresponding to the specified directory.\n";
print "Example:  $example\n\n";

while ($url_cgiBase eq "")
{
	print "URL: ";
	local $trial_url = <STDIN>;
	chomp $trial_url;

	if ($trial_url !~ /^\//) 
	{
		print "Your url specification must start with a / character\n";
		print "as it must be an absolute path.\n";
	} 
	else 
	{
		$_ = $trial_url;
		if (/\/$/)
		{
			chop;
		}
		$url_cgiBase = $_;
	}
}

#set up user directory
if ($username eq "root")
{
	$example = "/var/webmo";
}
else
{
	$example = "$homedir/webmo";
}
&divider;
print "SET UP USER DIRECTORY\n\n";
print "The script will now create a directory that will be used to store\n";
print "user profiles, passwords, jobs, and other private data.  This directory\n";
print "should meet the following requirements:\n";
print "  - Directory is NOT in the server's webspace\n";
print "  - You need to have permission to write to this directory\n";
print "  - The parent of the specified directory must already exists\n\n";
print "Example:  $example\n\n";

while ($userBase eq "")
{
	local $trial_directory = &complete("Directory: ");
	chomp $trial_directory;

	if ($trial_directory !~ /^\//) 
	{
		print "Your directory specification must start with a / character\n";
		print "as it must be an absolute directory.  You cannot use ~ to\n";
		print "indicate your home directory, nor . to use a relative\n";
		print "directory.\n";
	} 		
	elsif (!(-d $trial_directory))
	{
		print "That directory does not exist.\n";
		print "Create directory [y/n]:";
		
		local $choice = "";
		local $trial_choice = "";
		$trial_choice = <STDIN>;
		chomp $trial_choice;
		
		if ($trial_choice =~ /^y/i)
		{
			$choice = "y";
		}
		elsif ($trial_choice =~ /^n/i)
		{
			$choice = "n";
		}
		
		if ($choice eq "y")
		{
			if (!mkdir($trial_directory, 0777))
			{
				print "Unable to create directory: $!\n";
			}
			else
			{
				$userBase = $trial_directory;
			}
		}
	}
	elsif (!(-w $trial_directory))
	{
		print "You don't have permission to write to that directory\n";
	}
	else
	{
		if (-e "$trial_directory/jobs" ||
			-e "$trial_directory/jobs.db" ||
			-e "$trial_directory/.jobs.index")
		{
			print "Previous WebMO installation detected at this location!\n";
			print "Please use the upgrade.pl script to upgrade, or remove\n";
			print "this directory before re-installing.\n";
			exit(0);
		}
	
		$_ = $trial_directory;
		if (/\/$/)
		{
			chop;			
		}
		$userBase = $_;
	}	
}

local ($dev, $ino, $mode) = stat($userBase);
if ($mode != 040777 && !$unattended_setup)
{
	print "\nThe directory you have specified is not world writable.  While this\n";
	print "is not necessarily a problem, it may be an indication of one.  The user\n";
	print "directory must be writable by the user under whose identity the WebMO\n";
	print "scripts run (usually 'nobody').  Would you like to attempt to make this\n";
	print "directory world writable (mode = 0777) now?\n\n";
	print "Change directory mode [y/n]:";

	local $choice = "";
	while ($choice eq "")
	{
		local $trial_choice = "";
		$trial_choice = <STDIN>;
		chomp $trial_choice;
		
		if ($trial_choice =~ /^y/i)
		{
			$choice = "y";
		}
		elsif ($trial_choice =~ /^n/i)
		{
			$choice = "n";
		}
	}
	
	if ($choice eq "y")
	{
		if (!chmod(0777, $userBase))
		{
			print "Could not changes directory mode.  Insufficient privileges?\n";
			print "Make sure to make this change manaully before accessing WebMO.\n";
		}
	}
}

#confirm choices, and begin installation
&divider;
print "Here are the configuration options that you have chosen\n";
print "License number:       $license\n";
print "Path to perl:         $perlPath\n";
print "Webserver name:       $webserver\n";
print "HTML directory:       $htmlBase\n";
print "HTML URL:             $url_htmlBase\n";
print "CGI script directory: $cgiBase\n";
print "CGI script URL:       $url_cgiBase\n";
print "User files directory: $userBase\n\n";
print "Continue with installation [y/n]:";

local $choice = "";
$choice = "y" if $unattended_setup;

while ($choice eq "")
{
	local $trial_choice = "";
	$trial_choice = <STDIN>;
	chomp $trial_choice;
	
	if ($trial_choice =~ /^y/i)
	{
		$choice = "y";
	}
	elsif ($trial_choice =~ /^n/i)
	{
		$choice = "n";
	}
}
if ($choice eq "n")
{
	print "Exiting installation.\n";
	exit(0);
}

#setup CGI scripts
print "Setting up CGI scripts...";
local $scripts = "./cgi-bin/*.{cgi,pm}";
while (<${scripts}>)
{
	open(script, "<$_");
	local @scriptContents = <script>;
	close(script);

	/cgi\-bin\/(.*)$/;
	open(temp, ">$cgiBase/$1");
	
	print temp "#!$perlPath\n\n";
	print temp "# This script is copyright (c) 2019 by WebMO, LLC, all rights reserved.\n";
	print temp "# Its use is subject to the license agreement that can be found at the following\n";
	print temp "# URL:  http://www.webmo.net/license\n\n";
	
	print temp @scriptContents;
	
	close(temp);
	
	chmod 0755, "$cgiBase/$1";
}
#copy and external CGI libraries (don't add copyright, since these are not written by us!)
system("cp -pr ./cgi-bin/lib $cgiBase");

#copy REST libraries
system("cp -pr ./cgi-bin/REST $cgiBase") if ($enterprise);

print "finished\n";

#try and determine number of local cores
my $ncores = `getconf _NPROCESSORS_ONLN  2> /dev/null || getconf NPROCESSORS_ONLN  2> /dev/null`;
chomp $ncores;
$ncores = $ncores > 0 ? $ncores : 1;

#setup INT files
print "Setting up interface files...";
mkdir "$cgiBase/interfaces", 0777;
system("cp -p ./cgi-bin/interfaces/*.int.disabled $cgiBase/interfaces");
system("cp -p ./cgi-bin/interfaces/*.conf $cgiBase/interfaces") if ($enterprise);
system("cp -p ./cgi-bin/interfaces/*.tmpl $cgiBase/interfaces");
system("cp -p ./cgi-bin/interfaces/*.vars $cgiBase/interfaces");
system("cp -p ./cgi-bin/interfaces/fragments.txt $cgiBase/interfaces");
open(temp, ">$cgiBase/interfaces/globals.int");
print temp "version=\"$version\"\n";
print temp "license=\"$license\"\n";
print temp "userBase=\"$userBase\"\n";
print temp "htmlBase=\"$htmlBase\"\n";
print temp "cgiBase=\"$cgiBase\"\n";
print temp "webserver=\"autodetect\"\n";
print temp "webserverProtocol=\"autodetect\"\n";
print temp "host=\"$host\"\n";
print temp "ncores=\"$ncores\"\n";
print temp "url_htmlBase=\"$url_htmlBase\"\n";
print temp "url_cgiBase=\"$url_cgiBase\"\n";
print temp "systemScratch=\"$systemScratch\"\n";
print temp "whereisPath=\"$whereisPath\"\n";
print temp "perlPath=\"$perlPath\"\n";
print temp "psRegExp=\"$psRegExp\"\n";
print temp "owner=\"$owner\"\n";
print temp "servers=\"$host,0\"\n";
print temp "externalBatchQueue=\"\"\n";
print temp "externalAuthentication=\"\"\n";
print temp "loginMsg=\"\"\n";
print temp "loginMsgTimestamp=\"\"\n";
print temp "jupyterUrl=\"http://localhost:8888\"\n";
print temp "sudoEnabled=\"\"\n";
print temp "userStorageEnabled=\"\"\n";
print temp "uniqueId=\"$uniqueId\"\n";
close(temp);

local $interfaceFiles = "$cgiBase/interfaces/*.int";
chmod 0777, $_ while (<${interfaceFiles}>);
$interfaceFiles = "$cgiBase/interfaces/*.int.disabled";
chmod 0777, $_ while (<${interfaceFiles}>);
chmod 0777, "$cgiBase/interfaces/fragments.txt";
chmod 0777, "$cgiBase/interfaces/pbs.conf";
chmod 0777, "$cgiBase/interfaces/authen.conf";

print "finished\n";

#setup HTML files
print "Setting up HTML source files...";
system("cp -pr ./source/* $htmlBase");

print "finished\n";

#setup user directory
print "Setting up user directory...";
open(temp, ">$userBase/log");
close(temp);
chmod 0777, "$userBase/log";
open(temp, ">$userBase/errors");
close(temp);
chmod 0777, "$userBase/errors";
open(temp, ">$userBase/queue");
close(temp);
chmod 0777, "$userBase/queue";

$require++;
require("jobcontrol.cgi");
require("usercontrol.cgi");
require("groupcontrol.cgi");
$require--;
chmod 0777, "$userBase/jobs.db";
chmod 0777, "$userBase/.jobs.index";
chmod 0777, "$userBase/users.db";
chmod 0777, "$userBase/.users.index";
chmod 0777, "$userBase/groups.db";
chmod 0777, "$userBase/.groups.index";

&create_group('webmo');
&create_user('admin', 'webmo', '', 1);
chmod 0777, "$userBase/admin";

my %group_profile;
$group_profile{'timeLimit'} = -1;
$group_profile{'jobTimeLimit'} = -1;
foreach ('enabledInterfaces', 'enabledServers', 'enabledQueues')
{
	$group_profile{$_} = 'all';
}
#setup the group at allow new users to join by default, without a group password
$group_profile{'allowNewUsers'} = 1;
$group_profile{'groupPassword'} = crypt("", pack("c2", int(rand(26)) + 65, int(rand(26)) + 65));
&set_group_profile('webmo', \%group_profile);

print "finished\n\n";

#setup scratch directory
print "Setting up system scratch directory...";
mkdir "$systemScratch/webmo-$uniqueId", 0777;
print "finished\n";

#run FINDFILES
print "Locating system files...";
system("$perlPath scripts/findfiles.pl $cgiBase/interfaces/globals.int");
print "finished\n";

#run PSCHECK
print "Setting up `ps`...";
system("$perlPath scripts/pscheck.pl $cgiBase/interfaces/globals.int");
print "finished\n";

#run DIAGNOSE
print "Running diagnostic tests...";
system("$perlPath scripts/diagnose.pl $cgiBase/interfaces/globals.int");
print "finished\n";
if (`grep Failed diagnose.html`)
{
	print "Errors were detected during diagnostic tests; view diagnose.html for details\n";
	print "Do you wish to open this file in your browser now?";
	local $choice = "";
	$choice = <STDIN>;
	chomp $choice;
		
	if ($choice =~ /^y/i)
	{
		my @browsers = ();
		my $cwd = `pwd`;
		chomp $cwd;
		&find_system_file("netscape", \@browsers) unless (@browsers);
		&find_system_file("mozilla", \@browsers) unless (@browsers);
		system("$browsers[0] file:$cwd/diagnose.html");
	}
}

#setup computational servers
mkdir "$cgiBase/servers", 0777;
system("cp -p scripts/findfiles.pl $cgiBase/servers");
system("cp -p scripts/pscheck.pl $cgiBase/servers");
mkdir "$cgiBase/queues", 0777;

#copy diagnose.pl and secure.pl scripts
system("cp -p scripts/diagnose.pl $cgiBase");
system("cp -p scripts/secure.pl $cgiBase");

#do any OEM specific setup
my $oem_setup_script = $ENV{'WEBMO_OEM_SCRIPT'};
if ($oem_setup_script ne "" && -e $oem_setup_script)
{
	require("$oem_setup_script");
}

&divider;
print "FINISH SETUP\n\n";
print "The remainder of the WebMO setup will be done through the WebMO\n";
print "administrative tools.  The administrative tools facilitate configuration\n";
print "of system preferences, configuration of any packages (GAMESS, Gaussian,\n";
print "MOPAC, MolPro, NWChem, Firefly, Orca, PQS, PSI4, QChem, TeraChem, Tinker,\n";
print "Quantum Espresso, VASP, etc.) and adding/editing of users.\n\n";

print "Access WebMO with your web browser at the following URL: \n";
print "\thttp://${webserver}$url_cgiBase/login.cgi\n\n";

print "Login as the user 'admin' with a blank password. You will be prompted\n";
print "to change your password at that time.  After changing the admin password,\n";
print "you will be prompted to register your copy of WebMO.  You will then be\n";
print "brought to the administration home page.\n\n";
&pause;
print "Click on the 'System Manager' and check the location of the scratch\n";
print "directory, which you may change if desired.  Click 'Return to Admin'\n";
print "to return to the administration home page.\n\n";

print "Click on the 'Interface Manager' and enable the interfaces to any\n";
print "computational chemistry packages that you have already installed on your\n";
print "system by clicking the corresponding 'Enable interface' icon.\n";
print "Configure the interfaces by clicking the 'Edit interface' icon, and make any\n";
print "neccessary changes in the interface configuration, and then click 'Submit'\n";
print "to commit the changes and 'Return' to get back to the Interface Manager.\n";
print "Click 'Return to Admin' to return to the administration home page.\n\n";

print "Click on the 'User Manager' and then the 'New User' button to create WebMO\n";
print "users. Click 'Return to User Manager' to return to the user manager.\n";
print "Click 'Return to Admin' to return to the administration home page.\n\n";

print "Setup is now complete.  Click the 'Logout' button to logout of WebMO.\n";
print "You may now login as a WebMO user and run a test job.\n\n";
########################################################################
#  Subroutines

sub divider {
	print ">", "=" x 58, "<", "\n";
	print "\n";
}

sub pause
{
print "Enter to continue";
local $temp = <STDIN> unless $unattended_setup;
}

sub find_system_file
{
	local($systemFile, *list) = @_;	
	local $output = `whereis $systemFile`;
	$output = `which $systemFile` if ($output eq '');

	@list = ();

	$output =~ tr/\n/ /;
	if ($output =~ /$systemFile: (.*)/)
	{
		$output = $1;
	}
	
	local @options = split(/\s+/, $output);
	foreach (@options)
	{
		if (/$systemFile$/)
		{
			push @list, $_;
		}
	}
}

sub complete
{
	local $complete = "\004";
    local $kill     = "\003";	
    local $erase1 =   "\177";
    local $erase2 =   "\010";
    local @cmp_lst;        
    local ($prompt) = @_;        
    local $path = "";
    local $len = 0;
    
    local *dir;
    print($prompt, $path);

	system('stty raw -echo');
    while (($_ = getc(STDIN)) ne "\r")
    {
    	$path = substr($path, 0, $len);

		$path =~ /(.*)\/[^\/]*$/;
    	$current_path = $1."/";
	    opendir(dir,  $current_path =~ /^[\/.]/ ? $current_path : "./".$current_path);
	    @cmp_lst = readdir(dir);
	    closedir(dir);
			    
	    foreach (@cmp_lst)
	    {
	    	$_ = $current_path.$_;
	    }    	
    	
        # (TAB) attempt completion
        if ($_ eq "\t")
        {
        	@match = grep(/^$path/, @cmp_lst);
            $matches = @match;
            $l = length($test = shift(@match));
            unless ($#match < 0)
            {
            foreach $cmp (@match)
            	{
					until (substr($cmp, 0, $l) eq substr($test, 0, $l))
                	{
                    	$l--;
                    }
                }
                print("\a");
            }
            print($test = substr($test, $len, $l - $len));
            $len = length($path .= $test);
            
            if (-d $path && $matches == 1)
            {
				print "/";
            	$len = length($path .= "/");            	
            }
        }
    	
        # (^D) completion list
        if ($_ eq $complete)
        {
	    	print(join("\r\n", '', grep(/^$path/, @cmp_lst)), "\r\n");
    	    print($prompt, $path);
        };
    
        # (DEL) || (BS) erase
        if ($_ eq $erase1 || $_ eq $erase2)
        {
			if ($len)
        	{
		        print("\b \b");
		        $len--;
		    }
        }
        
        # (^C) kill
        if ($_ eq $kill)
        {
			system('stty -raw echo');
			print "\n";
	       	exit(0);
        }
                
        # printable char
        if (ord >= 32 && $_ ne $erase1)
        {
        	$path .= $_;
        	$len++;
	        print;
        }
    }
   
    system('stty -raw echo');
    print "\n";
    return $path;
}

sub escape
{
	my ($input) = @_;
	my $string;
	($string = $input) =~ s/([^\w ])/sprintf("%%%02lx", ord($1))/eg;
	#for javascript compatability
	$string =~ s/ /%20/g;
	return $string;
}
