WebMO installation and upgrade instructions on various platforms can be found at:
https://www.webmo.net/support/index.html
