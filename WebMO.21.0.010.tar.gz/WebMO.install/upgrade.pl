# This script is copyright (c) 2006 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

use lib 'cgi-bin';
use lib 'cgi-bin/lib';

local $version;
local $pro;
local $enterprise;

local $globals = "";
local $old_version="";
local $userBase="";
local $htmlBase="";
local $cgiBase="";
local $perlPath="";
local $webserver="";
local $host="";
local $license;

umask 0;

#if necessary on Windows, bootstrap ourself to elevate privileges
my $os = $^O;
if ($os =~ /MSWin/ && !($ARGV[0] eq 'win32_elevated'))
{
	my $ver_string = `ver`;
	my ($ver) = $ver_string =~ /Version (\d+\.\d+)/;
	#one Vista and higher, elevate privileges to avoid UAC issues
	if ($ver >= 6.0)
	{
		system("scripts\\elevate perl upgrade.pl win32_elevated");
		exit(0);
	}
}

#read version
open(temp, "<version");
$version = <temp>;
chomp $version;
close(temp);

#Check for an unattended upgrade
if (-e $ARGV[0] && $ARGV[0] =~ /globals\.int$/) {
	$unattended_setup = 1;
	$globals = $ARGV[0];
}

#Determine if this is a pro version
#Go ahead and tinker, this only changes what the installer displays, not what
#version you actually get :-)
if ($version =~ /p$/) { $pro = 1; }
if ($version =~ /e$/) { $enterprise = 1; }

print "\n";
if ($enterprise) { print "WELCOME TO WEBMO ENTERPRISE VERSION $version UPGRADE\n\n"; }
elsif ($pro) { print "WELCOME TO WEBMO PRO VERSION $version UPGRADE\n\n"; }
else { print "WELCOME TO WEBMO BASIC VERSION $version UPGRADE\n\n"; }
print "In order to complete your WebMO upgrade, you will be asked a few simple\n";
print "questions about file locations.  The WebMO files will then\n";
print "be updated on this server.\n";
&pause;

#make sure the user has backed up their present installation
&divider;
print "Have you backed up your present WebMO installation [y/n]:";
local $choice = "";
while (!$unattended_setup && $choice eq "")
{
	local $trial_choice = "";
	$trial_choice = <STDIN>;
	chomp $trial_choice;
	
	if ($trial_choice =~ /^y/i)
	{
		$choice = "y";
	}
	elsif ($trial_choice =~ /^n/i)
	{
		$choice = "n";
	}
}
if ($choice eq "n")
{
	print "It is highly recommended that you backup you current WebMO installation.\n";
	print "For example,\n\n";
	print "% tar cvf webmo_backup.tar cgiBase htmlBase userBase\n\n";
	print "where cgiBase, htmlBase, and userBase are specified in the globals.int\n";
	print "configuration file.\n\n";
	
	print "Exiting upgrade.\n";
	exit(0);
}

#if necessary, call the windows-specific installation script
if ($os =~ /MSWin/)
{
	do(".\\scripts\\upgrade_win32.pl");
	print $@ if $@;
	exit(0);
}

#ask the user to locate globals.int
&divider;
print "Please locate the FULL PATH to the WebMO configuration file, 'globals.int.'\n";
print "This file is installed in the location <webmo>/cgi-bin/interfaces/globals.int.\n\n";

while ($globals eq "")
{
	local $trial_globals = &complete("Location: ");
	chomp $trial_globals;

	if (!(-f $trial_globals))
	{
		print "That file does not exist.\n";
	}
	elsif (!(-w $trial_globals))
	{
		print "You don't have permission to write to that file\n";
	}
	else
	{
		$globals = $trial_globals;
	}
}

#parse globals.int
local *handle;
open(handle, "<$globals");

while(<handle>)
{
	chomp;
	local ($variable, $value) = split(/=/, $_, 2);
	
	$_ = $value;
	chop;
	($value) = /\"(.*)/;
	
	$cgiBase = $value		if($variable eq "cgiBase");
	$userBase = $value		if($variable eq "userBase");
	$htmlBase = $value		if($variable eq "htmlBase");
	$old_version = $value	if($variable eq "version");
	$perlPath = $value		if($variable eq "perlPath");
	$webserver = $value		if($variable eq "webserver");
	$jupyterUrl = $value		if($variable eq "jupyterUrl");
	$host = $value			if($variable eq "host");
	$license = $value		if($variable eq "license");
}

close(handle);

if ($old_version eq "" || $cgiBase eq "" || $userBase eq "" || $htmlBase eq "")
{
	print "Invalid globals.int file\n";
	print "Exiting upgrade.\n";
	exit(0);
}

#check for running jobs; if located, exit
if (-e "$userBase/daemon")
{
	print "Cannot upgrade WebMO when jobs are running.  Disable queue and\n";
	print "kill all running jobs before performing upgrade; re-enable queue\n";
	print "when the upgrade is complete.\n\n";
	print "If you sure that no WebMO jobs are running or queued, it is possible\n";
	print "that WebMO may not have shut down properly.  In this case, simply\n";
	print "delete the file $userBase/daemon to circumvent this message.\n";
	exit(0);
}

#confirm choices, and begin upgrade
&divider;

if ($old_version =~ /p/ && $version !~ /p|e/)
{
	print "WARNING: You are \"upgrading\" from WebMO Pro to WebMO free.\n";
	print "This operation is unsupported and may cause problems!\n\n";
}
if ($old_version =~ /e/ && $version !~ /e/)
{
	print "WARNING: You are \"upgrading\" from WebMO Enterprise to WebMO Pro/free.\n";
	print "This operation is unsupported and may cause problems!\n\n";
}

print "You have chosen to update from WebMO $old_version to WebMO $version.\n";
print "Continue with upgrade [y/n]:";

local $choice = "";
while (!$unattended_setup && $choice eq "")
{
	local $trial_choice = "";
	$trial_choice = <STDIN>;
	chomp $trial_choice;
	
	if ($trial_choice =~ /^y/i)
	{
		$choice = "y";
	}
	elsif ($trial_choice =~ /^n/i)
	{
		$choice = "n";
	}
}
if ($choice eq "n")
{
	print "Exiting upgrade.\n";
	exit(0);
}

if (($pro || $enterprise) && $old_version !~ /p|e$/)
{
	$license = "";
	
	#optionally read new Pro/Enterprise license number from command line
	if ($unattended_setup && -e $ARGV[1]) {
		$license = $ARGV[1];
	}
	
	&divider;
	print "ENTER PRO/ENTERPRISE LICENSE INFORMATION\n\n";
	print "It is time to enter your WebMO license information.\n";
	print "Please enter your license information exactly as it was\n";
	print "received by you when you purchased WebMO.\n\n";

	while ($license eq "")
	{
		print "License number: ";
		local $trial_license = <STDIN>;
		chomp $trial_license;

		if ($trial_license !~ /\d\d\d\d-\d\d\d\d-\d\d\d\d/)
		{
			print "The license must be in the form xxxx-xxxx-xxxx\n";
		}
		else
		{
			# This operation is check-summing your license information to help you catch
			# typographical errors.  Sure, you could easily circumvent it, but why would
			# you want to do that, unless you didn't have a valid license number!?!
		
			local ($first, $second, $third) = split(/-/, $trial_license);
					
			local @checksum = ( (($first*3+7) | ($second*5+13)) % 10, (($first*7+17) & ($second*11+19)) % 10, (($first*13+23) ^ ($second*17+29)) % 10, (($first*19+31) & ($second*23+33) ^ $first) % 10);
		
			$third =~ /(\d)(\d)(\d)(\d)/;
			if ($1 != $checksum[0] || $2 != $checksum[1] || $3 != $checksum[2] || $4 != $checksum[3])
			{
				print "The license number you entered was invalid.\n";
			}
			else
			{
				$license = $trial_license;
			}
		}
	}
}

#setup CGI scripts
print "Setting up CGI scripts...";
local $scripts = "./cgi-bin/*.{cgi,pm}";
while (<${scripts}>)
{
	open(script, "<$_");
	local @scriptContents = <script>;
	close(script);

	/cgi\-bin\/(.*)$/;
	open(temp, ">$cgiBase/$1");
	
	print temp "#!$perlPath\n\n";
	print temp "# This script is copyright (c) 2019 by WebMO, LLC, all rights reserved.\n";
	print temp "# Its use is subject to the license agreement that can be found at the following\n";
	print temp "# URL:  http://www.webmo.net/license\n\n";
	
	print temp @scriptContents;
	
	close(temp);
	
	chmod 0755, "$cgiBase/$1";
}
#copy and external CGI libraries (don't add copyright, since these are not written by us!)
system("cp -prf ./cgi-bin/lib $cgiBase");

#copy REST libraries
system("cp -pr ./cgi-bin/REST $cgiBase") if ($enterprise);

print "finished\n";

#setup INT files
print "Setting up interface files...";
if (!(-d "$cgiBase/interfaces"))
{
	mkdir "$cgiBase/interfaces", 0777;
}

#add any new interface files, update old ones (and upgrade batch queues, but not remote servers)
local $interfaceFiles = "./cgi-bin/interfaces/*.int.disabled";
while (<${interfaceFiles}>)
{
	/\/interfaces\/(.*)\.int\.disabled$/;
	my $queues = "$cgiBase/queues/*";
	my @queueList = <${queues}>;
	foreach my $directory ("$cgiBase/interfaces", @queueList)
	{
		if (-e "$directory/$1.int")
		{
			&update_interface("./cgi-bin/interfaces/$1.int.disabled", "$directory/$1.int");
		}
		elsif (-e "$directory/$1.int.disabled")
		{
			&update_interface("./cgi-bin/interfaces/$1.int.disabled", "$directory/$1.int.disabled");
		}
		else
		{
			system("cp -p ./cgi-bin/interfaces/$1.int.disabled $directory");
			chmod 0777, "$directory/$1.int.disabled";
		}
	}
}

#backup fragment file, if necessary
if (-e "$cgiBase/interfaces/fragments.txt")
{
	my $number = 0;
	while (-e "$cgiBase/interfaces/fragments.$number") { $number++ }
	system("mv $cgiBase/interfaces/fragments.txt $cgiBase/interfaces/fragments.$number");
}
#copy fragments file
system("cp -p ./cgi-bin/interfaces/fragments.txt $cgiBase/interfaces");
chmod 0777, "$cgiBase/interfaces/fragments.txt";

#add pbs.conf and authen.conf files, if necessary
if ($enterprise)
{
	if (!(-e "$cgiBase/interfaces/pbs.conf"))
	{
		system("cp -p ./cgi-bin/interfaces/pbs.conf $cgiBase/interfaces");
		chmod 0777, "$cgiBase/interfaces/pbs.conf";
	}
	else
	{
		&update_interface("./cgi-bin/interfaces/pbs.conf", "$cgiBase/interfaces/pbs.conf");
	}

	if (!(-e "$cgiBase/interfaces/authen.conf"))
	{
		system("cp -p ./cgi-bin/interfaces/authen.conf $cgiBase/interfaces");
		chmod 0777, "$cgiBase/interfaces/authen.conf";
	}
	else
	{
		&update_interface("./cgi-bin/interfaces/authen.conf", "$cgiBase/interfaces/authen.conf");
	}
}

#add log file, if necessary
if (!(-e "$userBase/log"))
{
	open(temp, ">$userBase/log");
	close(temp);
	chmod 0777, "$userBase/log";
}

#add any new template files
local $templateFiles = "./cgi-bin/interfaces/*.tmpl";
while (<${templateFiles}>)
{
	/\/interfaces\/(.*)\.tmpl$/;
	#backup any existing templates
	if (-e "$cgiBase/interfaces/$1.tmpl")
	{
		local $number = 0;
		while (-e "$cgiBase/interfaces/$1.$number") { $number++ }
		system("mv $cgiBase/interfaces/$1.tmpl $cgiBase/interfaces/$1.$number");
	}
	
	system("cp -p ./cgi-bin/interfaces/$1.tmpl $cgiBase/interfaces");
}
#copy over built-in custom variables
system("cp -p ./cgi-bin/interfaces/*.vars $cgiBase/interfaces");

print "finished\n";

#setup HTML files
print "Setting up HTML source files...";
system("cp -pr ./source/* $htmlBase");
unlink("$htmlBase/java/moviewer.zip");

print "finished\n";

#update version in globals.int
#also, add systemScratch, servers, and pbsMode variable, if neccessary
local $systemScratchExists = 0;
local $serversExists = 0;
local $externalBatchQueue = 0;
local $loginMsgExists = 0;
local $ncoresExists = 0;

open(handle, "+>>$globals");
seek handle, 0, 0;						# rewind
	
local @contents = <handle>;
	
seek handle, 0, 0;						# rewind again
truncate $globals, 0;					# empty the file
	
foreach (@contents)
{
	chomp;	
	local($variable, $value) = split(/=/, $_, 2);
	$value = "\"$version\""		if ($variable eq "version");
	$value = "\"$license\""		if ($variable eq "license");
	$systemScratchExists = 1	if ($variable eq "systemScratch");
	$serversExists = 1			if ($variable eq "servers");
	$externalBatchQueue = 1			if ($variable eq "externalBatchQueue");
	$externalAuthentication = 1			if ($variable eq "externalAuthentication");
	$sudoEnabled = 1			if ($variable eq "sudoEnabled");
	$userStorageEnabled = 1		if ($variable eq "userStorageEnabled");
	$loginMsgExists = 1 		if ($variable eq "loginMsg");
	$uniqueIdExists = 1			if ($variable eq "uniqueId");
	$ncoresExists = 1			if ($variable eq "ncores");
		
	print handle "$variable=$value\n";
}

if (!$systemScratchExists)
{
	print handle "systemScratch=\"/tmp\"\n";

	#setup scratch directory
	print "Setting up system scratch directory...";
	mkdir "/tmp/webmo", 0777;
	
	print "finished\n\n";
	
	print "WebMO scratch directory has been changed to /tmp.  You may wish to\n";
	print "reconfigure this from the System Manager.\n"
}
print handle "servers=\"$host,0\"\n"	if (!$serversExists);
print handle "externalBatchQueue=\"\"\n"		if (!$externalBatchQueue);
print handle "externalAuthentication=\"\"\n"	if (!$externalAuthentication);
print handle "sudoEnabled=\"\"\n"	if (!$sudoEnabled);
print handle "userStorageEnabled=\"\"\n"	if (!$userStorageEnabled);
print handle "uniqueId=\"$$\"\n"	if (!$uniqueIdExists);
print handle "ncores=\"1\"\n"	if (!$ncoresExists);
if (!$loginMsgExists)
{
	print handle "loginMsg=\"\"\n";
	print handle "loginMsgTimestamp=\"\"\n";
}
if ($webserver eq "")
{
	$webserver = $host;
	print handle "webserver=\"$webserver\"\n";
}
if ($webserverProtocol eq "")
{
	$webserverProtocol = "autodetect";
	print handle "webserverProtocol=\"$webserverProtocol\"\n";
}
if ($jupyterUrl eq "")
{
	$jupyterUrl = "http://localhost:8888";
	print handle "jupyterUrl=\"$jupyterUrl\"\n";
}

close(handle);

#run FINDFILES
print "Locating system files...";
system("$perlPath scripts/findfiles.pl $cgiBase/interfaces/globals.int");
print "finished\n";

#run PSCHECK
print "Setting up `ps`...";
system("$perlPath scripts/pscheck.pl $cgiBase/interfaces/globals.int > /dev/null");
print "finished\n";

#setup computational servers
mkdir("$cgiBase/servers", 0777);
system("cp -p scripts/findfiles.pl $cgiBase/servers");
system("cp -p scripts/pscheck.pl $cgiBase/servers");
mkdir("$cgiBase/queues", 0777) if ($pro || $enterprise);

#copy diagnose.pl and secure.pl scripts
system("cp -p scripts/diagnose.pl $cgiBase");
system("cp -p scripts/secure.pl $cgiBase");

#update convert jobs and users file to a databse
unless (-e "$userBase/jobs.db")
{
	system("$perlPath scripts/convert_jobs.pl $userBase/jobs $userBase/jobs.db");
	chmod 0777, "$userBase/jobs.db";
	system("mv $userBase/jobs $userBase/backup/jobs.old.txt");
}
unless (-e "$userBase/users.db")
{
	system("$perlPath scripts/convert_users.pl $userBase/users $userBase/users.db $userBase");
	chmod 0777, "$userBase/users.db";
	system("mv $userBase/users $userBase/backup/users.old.txt");
}
unless (-e "$userBase/groups.db")
{
	$require++;
	require("groupcontrol.cgi");
	$require--;

	&create_group('webmo');
	my %group_profile;
	$group_profile{'timeLimit'} = -1;
	$group_profile{'jobTimeLimit'} = -1;
	foreach ('enabledInterfaces', 'enabledServers', 'enabledQueues')
	{
		$group_profile{$_} = 'all';
	}
	&set_group_profile('webmo', \%group_profile);
	
	chmod 0777, "$userBase/groups.db";
	chmod 0777, "$userBase/.groups.index";
}

&divider;
print "Do you wish to purge your jobs database of previously deleted jobs?\n";
print "This will optimize the performance of WebMO on heavily utilized systems.\n";
print "Note that this can be done at any time using the 'scripts/clean_jobsdb.pl'\n";
print "script.\n\n";

print "Do you wish to purge deleted jobs? [y/n]:";
local $choice = "";
while (!$unattended_setup && $choice eq "")
{
	local $trial_choice = "";
	$trial_choice = <STDIN>;
	chomp $trial_choice;
	
	if ($trial_choice =~ /^y/i)
	{
		$choice = "y";
	}
	elsif ($trial_choice =~ /^n/i)
	{
		$choice = "n";
	}
}
if ($choice eq 'y')
{
	unlink("$userBase/backup/deleted.db");
	system("$perlPath scripts/clean_jobsdb.pl $userBase/jobs.db $userBase/backup/deleted.db");
}

&divider;
print "WEBMO UPDATE COMPLETE\n\n";

########################################################################
#  Subroutines

sub divider {
	print ">", "=" x 58, "<", "\n";
	print "\n";
}

sub pause
{
print "Enter to continue";
local $temp = <STDIN> unless $unattended_setup;
}

sub complete
{
	local $complete = "\004";
    local $kill     = "\003";	
    local $erase1 =   "\177";
    local $erase2 =   "\010";
    local @cmp_lst;        
    local ($prompt) = @_;        
    local $path = "";
    local $len = 0;
    
    local *dir;
    print($prompt, $path);

	system('stty raw -echo');    
    while (($_ = getc(STDIN)) ne "\r")
    {
    	$path = substr($path, 0, $len);

		$path =~ /(.*)\/[^\/]*$/;
    	$current_path = $1."/";
	    opendir(dir,  $current_path =~ /^[\/.]/ ? $current_path : "./".$current_path);
	    @cmp_lst = readdir(dir);
	    closedir(dir);
			    
	    foreach (@cmp_lst)
	    {
	    	$_ = $current_path.$_;
	    }    	
    	
        # (TAB) attempt completion
        if ($_ eq "\t")
        {
        	@match = grep(/^$path/, @cmp_lst);
            $matches = @match;
            $l = length($test = shift(@match));
            unless ($#match < 0)
            {
				foreach $cmp (@match)
            	{
					until (substr($cmp, 0, $l) eq substr($test, 0, $l))
                	{
                    	$l--;
                    }
                }
                print("\a");
            }
            print($test = substr($test, $len, $l - $len));
            $len = length($path .= $test);
            
            if (-d $path && $matches == 1)
            {
				print "/";
            	$len = length($path .= "/");            	
            }
        }
    	
        # (^D) completion list
        if ($_ eq $complete)
        {
	    	print(join("\r\n", '', grep(/^$path/, @cmp_lst)), "\r\n");
    	    print($prompt, $path);
        };
    
        # (DEL) || (BS) erase
        if ($_ eq $erase1 || $_ eq $erase2)
        {
			if ($len)
        	{
		        print("\b \b");
		        $len--;
		    }
        }
        
        # (^C) kill
        if ($_ eq $kill)
        {
			system('stty -raw echo');
			print "\n";
	       	exit(0);
        }
                
        # printable char
        if (ord >= 32 && $_ ne $erase1)
        {
        	$path .= $_;
        	$len++;
	        print;
        }        
    }
   
    system('stty -raw echo');
    print "\n";
    return $path;
}

sub update_interface
{
	local ($newInterfaceName, $oldInterfaceName) = @_;
	local (*newInterface);
	local (*oldInterface);
	local @oldInterfaceContents;
	local $needNewline;
	open(oldInterface, "+>>$oldInterfaceName");
	seek oldInterface, 0, 0;
	while(<oldInterface>)
	{
		local($variable, $value) = split(/=/, $_, 2);
		push(@oldInterfaceContents, $variable);
		if ($value !~ /\n$/) { $needsNewline = 1; }
	}
	seek oldInterface, 0, 2;
	#add a newline at the end, if neccessary
	if ($needsNewline) {
		print oldInterface "\n";
	}
	#upgrade the interface
	open(newInterface, "<$newInterfaceName");
	while(<newInterface>)
	{
		local($variable, $value) = split(/=/, $_, 2);
		chomp $value;
		if (grep($_ eq $variable, @oldInterfaceContents) == 0)
		{
			print oldInterface "$variable=$value\n";
		}
	}
	close(newInterface);
	close(oldInterface);
}

