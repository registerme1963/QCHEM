var bmenuItems =
[
  ["$Input File", "content1"],
  ["Choose Engine",  "content2"],
];

apy_tabsInit();
