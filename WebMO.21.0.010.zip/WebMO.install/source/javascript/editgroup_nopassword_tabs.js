var bmenuItems =
[
  ["$Permissions",  "content2"],
];

apy_tabsInit();