package Shibboleth;

use base 'Authen::Simple::Adapter';

&main::load_interface("interfaces/authen.conf");

sub check()
{
	my ($self, $username, $password) = @_;
	#just verify a matchup between the Apache-authenticated username and the one provied to WebMO
	return (lc $username) eq (lc $ENV{REMOTE_USER});
}
