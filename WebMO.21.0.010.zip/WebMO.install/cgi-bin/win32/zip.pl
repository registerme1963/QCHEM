# This script is copyright (c) 2007 by WebMO, LLC, all rights reserved
# Its use is subject to the license agreement that can be found at the following
# URL:  http://www.webmo.net/license

use Archive::Zip;

my $archive = shift @ARGV;
die "Usage: zip.pl archive.zip ..." unless ($archive ne '');

my $zip = new Archive::Zip();

my @files = @ARGV;
foreach my $file (@files)
{
	if (-d $file)
	{
		local(*dir);
		opendir(dir, "$file");
		push(@files, map("$file/$_", grep {!/^\./} readdir(dir)));
		closedir(dir);
	}
	$zip->addFileOrDirectory($file);
}

if ($archive eq '-')
{
	binmode(STDOUT);
	$zip->writeToFileHandle(STDOUT, 0);
}
else
{
	$zip->writeToFileNamed($archive);
}
